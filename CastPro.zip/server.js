import express from 'express';
import cors from 'cors';
import { db } from './db.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

// --- AUTHENTICATION ---
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const users = db.getAll('users');
  const user = users.find(u => u.username === username && u.password === password);
  
  if (user) {
    res.json({ success: true, user: { id: user.id, username: user.username, role: user.role, name: user.full_name } });
  } else {
    res.status(401).json({ success: false, message: "Invalid username or password" });
  }
});

// --- GENERIC MASTER DATA ENDPOINTS ---
app.get('/api/masters/:table', (req, res) => {
  const { table } = req.params;
  res.json(db.getAll(table));
});

app.post('/api/masters/:table', (req, res) => {
  const { table } = req.params;
  const item = req.body;
  
  // Custom interlocking validations for Masters
  if (table === 'products') {
    if (!item.grade_id || !db.getById('grades', item.grade_id)) {
      return res.status(400).json({ success: false, message: "Product must be mapped to a valid Grade Master" });
    }
  }
  
  const created = db.insert(table, item);
  res.status(201).json(created);
});

app.put('/api/masters/:table/:id', (req, res) => {
  const { table, id } = req.params;
  const updated = db.update(table, id, req.body);
  if (updated) {
    res.json(updated);
  } else {
    res.status(404).json({ success: false, message: "Item not found" });
  }
});

app.delete('/api/masters/:table/:id', (req, res) => {
  const { table, id } = req.params;
  const deleted = db.delete(table, id);
  if (deleted) {
    res.json({ success: true });
  } else {
    res.status(404).json({ success: false, message: "Item not found" });
  }
});


// --- SALES & ORDER PROCESSING ---

// 1. Enquiry
app.post('/api/sales/enquiry', (req, res) => {
  const { customer_id, items, target_date } = req.body;
  
  // Interlock: Customer must exist
  const customer = db.getById('customers', customer_id);
  if (!customer) {
    return res.status(400).json({ success: false, message: "Customer Master does not exist. Please create the customer first." });
  }

  const newEnq = db.insert('enquiries', {
    customer_id,
    customer_name: customer.name,
    items, // array of { product_id, is_new_development, qty }
    target_date,
    date: new Date().toISOString().split('T')[0],
    status: 'Pending Quotation'
  });

  res.status(201).json({ success: true, data: newEnq });
});

// 2. Quotation
app.post('/api/sales/quotation', (req, res) => {
  const { enquiry_id, costing_details, lead_time_weeks, technical_specs, total_quote_rate } = req.body;
  
  // Interlock: Cannot create quotation without enquiry
  const enquiry = db.getById('enquiries', enquiry_id);
  if (!enquiry) {
    return res.status(400).json({ success: false, message: "Valid Enquiry ID is mandatory to generate a quotation." });
  }

  const newQtn = db.insert('quotations', {
    enquiry_id,
    customer_id: enquiry.customer_id,
    customer_name: enquiry.customer_name,
    costing_details,
    lead_time_weeks,
    technical_specs,
    total_quote_rate,
    date: new Date().toISOString().split('T')[0],
    status: 'Pending Approval', // Requires Sales Head approval workflow
    approved_by: null
  });

  // Update Enquiry Status
  db.update('enquiries', enquiry_id, { status: 'Quoted' });

  res.status(201).json({ success: true, data: newQtn });
});

// Approve Quotation (Sales Head workflow)
app.post('/api/sales/quotation/:id/approve', (req, res) => {
  const { id } = req.params;
  const { approver_name } = req.body;

  const qtn = db.getById('quotations', id);
  if (!qtn) {
    return res.status(404).json({ success: false, message: "Quotation not found." });
  }

  const updated = db.update('quotations', id, {
    status: 'Approved',
    approved_by: approver_name || "Sales Head"
  });

  res.json({ success: true, data: updated });
});

// 3. Purchase Order (PO)
app.post('/api/sales/po', (req, res) => {
  const { po_number, quotation_id, date, order_items } = req.body;
  
  // Interlock: PO must reference approved quotation
  const qtn = db.getById('quotations', quotation_id);
  if (!qtn) {
    return res.status(400).json({ success: false, message: "Reference Quotation ID is invalid." });
  }
  if (qtn.status !== 'Approved') {
    return res.status(400).json({ success: false, message: "Reference Quotation must be 'Approved' by Sales Head before creating a PO." });
  }

  // Interlock: Rate validation vs quotation
  // order_items: [{ product_id, quantity, rate }]
  for (const item of order_items) {
    // Basic rate check: rate must match quoted rate or be higher, and quantity shouldn't exceed reasonable limits.
    // In our simplified system, we compare with the total quote rate or log the validated items.
    if (Number(item.rate) <= 0) {
      return res.status(400).json({ success: false, message: "Invalid rate in PO. Rate must be greater than 0." });
    }
  }

  const newPO = db.insert('purchase_orders', {
    po_number,
    quotation_id,
    customer_id: qtn.customer_id,
    customer_name: qtn.customer_name,
    date,
    order_items,
    status: 'Active'
  });

  // Update Quotation status
  db.update('quotations', quotation_id, { status: 'PO Received' });

  res.status(201).json({ success: true, data: newPO });
});

// 4. Work Order (WO)
app.post('/api/sales/wo', (req, res) => {
  const { po_id, schedule_delivery_date } = req.body;

  // Interlock: WO only created against PO
  const po = db.getById('purchase_orders', po_id);
  if (!po) {
    return res.status(400).json({ success: false, message: "A valid Purchase Order reference is mandatory." });
  }

  // Interlock: Auto-fetch Product, Grade, Quantity from PO
  const workOrdersCreated = [];

  for (const item of po.order_items) {
    const product = db.getById('products', item.product_id);
    if (!product) {
      return res.status(400).json({ success: false, message: `Product ID ${item.product_id} in PO does not exist in Product Master.` });
    }
    const grade = db.getById('grades', product.grade_id);
    if (!grade) {
      return res.status(400).json({ success: false, message: `Grade mapping missing for Product ${product.name}.` });
    }

    const newWO = db.insert('work_orders', {
      po_id,
      po_number: po.po_number,
      customer_id: po.customer_id,
      customer_name: po.customer_name,
      product_id: product.id,
      product_name: product.name,
      product_code: product.code,
      grade_id: grade.id,
      grade_name: grade.name,
      quantity: item.quantity,
      net_weight_kg: product.net_weight,
      gross_weight_kg: product.gross_weight,
      schedule_delivery_date,
      date_created: new Date().toISOString().split('T')[0],
      status: 'Pending Planning',
      planned_qty: 0,
      produced_qty: 0,
      dispatched_qty: 0
    });
    workOrdersCreated.push(newWO);
  }

  db.update('purchase_orders', po_id, { status: 'Work Orders Created' });

  res.status(201).json({ success: true, data: workOrdersCreated });
});


// --- PRODUCTION PLANNING & EXECUTION ---

// 5. Production Planning
app.post('/api/production/plan', (req, res) => {
  const { work_order_id, planned_qty, planned_date, moulding_line, core_box_details, machine_capacity_tons } = req.body;

  // Interlock: Cannot plan without Work Order
  const wo = db.getById('work_orders', work_order_id);
  if (!wo) {
    return res.status(400).json({ success: false, message: "Valid Work Order ID is mandatory for production planning." });
  }

  // Interlock: Capacity validation
  const totalWeightTons = (wo.gross_weight_kg * planned_qty) / 1000;
  if (totalWeightTons > machine_capacity_tons) {
    return res.status(400).json({ success: false, message: `Planned load (${totalWeightTons.toFixed(2)} Tons) exceeds Moulding Line capacity (${machine_capacity_tons} Tons).` });
  }

  const newPlan = db.insert('production_plans', {
    work_order_id,
    po_number: wo.po_number,
    product_id: wo.product_id,
    product_name: wo.product_name,
    grade_id: wo.grade_id,
    grade_name: wo.grade_name,
    planned_qty,
    planned_date,
    moulding_line,
    core_box_details,
    date_created: new Date().toISOString().split('T')[0],
    status: 'Planned'
  });

  // Update WO planned quantity
  const updatedPlannedQty = (wo.planned_qty || 0) + Number(planned_qty);
  db.update('work_orders', work_order_id, {
    planned_qty: updatedPlannedQty,
    status: 'Scheduled'
  });

  res.status(201).json({ success: true, data: newPlan });
});

// 6. Melting Heat Initiation & Materials Loading
app.post('/api/production/heat/initiate', (req, res) => {
  const { furnace_id, grade_id, heat_date, materials_input } = req.body;

  // Interlock: Grade must exist
  const grade = db.getById('grades', grade_id);
  if (!grade) {
    return res.status(400).json({ success: false, message: "Valid Grade selection is mandatory to initiate a Heat." });
  }

  // materials_input: [{ material_id, qty_kg }]
  if (!materials_input || materials_input.length === 0) {
    return res.status(400).json({ success: false, message: "Melting cannot start without loading raw materials (Scrap/Alloys)." });
  }

  // Create Heat
  const newHeat = db.insert('melting_heats', {
    furnace_id,
    grade_id,
    grade_name: grade.name,
    heat_date,
    chemical_status: 'Pending Testing', // Chemical testing is pre-pour mandatory
    mechanical_status: 'Pending Testing',
    materials_deducted: false,
    status: 'Pouring Blocked', // Must pass chem test first
    close_reason: null
  });

  // Save the logged loaded materials
  materials_input.forEach(mat => {
    db.insert('melting_log_materials', {
      heat_id: newHeat.id,
      material_id: mat.material_id,
      qty_kg: Number(mat.qty_kg)
    });
  });

  res.status(201).json({ success: true, data: newHeat });
});

// 7. Chemical Testing (Pre-Pour)
app.post('/api/production/chemical/test', (req, res) => {
  const { heat_id, chemistry_readings } = req.body; 
  // chemistry_readings: { C: 3.25, Si: 1.95, ... }

  const heat = db.getById('melting_heats', heat_id);
  if (!heat) {
    return res.status(404).json({ success: false, message: "Heat records not found." });
  }

  const grade = db.getById('grades', heat.grade_id);
  if (!grade) {
    return res.status(404).json({ success: false, message: "Grade specification details missing." });
  }

  // Interlock: Chemical composition meets target range check
  const deviations = [];
  const specs = grade.chemical;

  for (const element in specs) {
    const reading = Number(chemistry_readings[element] || 0);
    const min = specs[element].min;
    const max = specs[element].max;

    if (reading < min || reading > max) {
      deviations.push(`${element}: Value ${reading}% is out of bounds [Min: ${min}%, Max: ${max}%]`);
    }
  }

  const pass = deviations.length === 0;

  const testRecord = db.insert('chemical_tests', {
    heat_id,
    chemistry_readings,
    deviations,
    status: pass ? 'Passed' : 'Failed',
    timestamp: new Date().toISOString()
  });

  // Update Heat Status
  db.update('melting_heats', heat_id, {
    chemical_status: pass ? 'Passed' : 'Failed',
    status: pass ? 'Pouring Approved' : 'Pouring Blocked'
  });

  res.status(201).json({
    success: true,
    passed: pass,
    deviations,
    data: testRecord
  });
});

// 8. Material Consumption (Deduct from inventory) & Heat Close
app.post('/api/production/heat/consume-and-close', (req, res) => {
  const { heat_id } = req.body;

  const heat = db.getById('melting_heats', heat_id);
  if (!heat) {
    return res.status(404).json({ success: false, message: "Heat not found." });
  }

  if (heat.materials_deducted) {
    return res.status(400).json({ success: false, message: "Inventory deduction already recorded for this Heat." });
  }

  // Retrieve materials loaded for this Heat
  const loggedMaterials = db.getAll('melting_log_materials').filter(m => m.heat_id === heat_id);
  if (loggedMaterials.length === 0) {
    return res.status(400).json({ success: false, message: "No raw materials inputs recorded. Cannot close Heat without material consumption." });
  }

  // Interlock: Auto deduction & shortage alert check
  const inventory = db.getAll('inventory');
  const alerts = [];

  loggedMaterials.forEach(logged => {
    const item = inventory.find(inv => inv.id === logged.material_id);
    if (item) {
      const originalStock = item.stock;
      item.stock = Math.max(0, item.stock - logged.qty_kg);
      
      if (item.stock < item.min_stock) {
        alerts.push(`Shortage Alert: ${item.name} stock level fell to ${item.stock} kg (Min Limit: ${item.min_stock} kg)`);
      }
    }
  });

  // Write inventory changes
  db.saveAll('inventory', inventory);

  // Close the Heat
  db.update('melting_heats', heat_id, {
    materials_deducted: true,
    status: heat.chemical_status === 'Passed' ? 'Completed' : 'Completed (Failed Chemistry)'
  });

  res.json({
    success: true,
    message: "Raw materials auto-deducted from inventory successfully.",
    alerts
  });
});

// 9. Production Execution (Actually creates individual Casting serial numbers)
app.post('/api/production/execution/record', (req, res) => {
  const { plan_id, heat_id, qty_cast, shift, worker_details } = req.body;

  const plan = db.getById('production_plans', plan_id);
  if (!plan) {
    return res.status(400).json({ success: false, message: "A valid Production Plan reference is required." });
  }

  // Interlock: Heat No. is mandatory for traceability
  const heat = db.getById('melting_heats', heat_id);
  if (!heat) {
    return res.status(400).json({ success: false, message: "Melting Heat No. is mandatory for production entry to maintain traceability." });
  }

  // Interlock: Heat must be poured (approved chemistry is ideal, but let's allow saving if they poured it, warning them if chem failed)
  if (heat.chemical_status !== 'Passed') {
    return res.status(400).json({ success: false, message: "Interlock Error: Chemical pre-pour test must be Passed before record execution pouring." });
  }

  // Create individual casting entries for tracking
  const createdCastings = [];
  const yearSuffix = new Date().getFullYear().toString().substr(-2);
  const count = db.getAll('castings').length;

  for (let i = 0; i < qty_cast; i++) {
    const castingSerial = `CAST-${yearSuffix}-${String(count + i + 1).padStart(5, '0')}`;
    const casting = db.insert('castings', {
      id: castingSerial,
      heat_id,
      plan_id,
      product_id: plan.product_id,
      product_name: plan.product_name,
      stage: 'Knockout Pending', // Progression: Knockout Pending -> Knockout Inspected -> Fettled -> Fettling Inspected -> Painted -> Dispatched
      knockout_status: 'Pending',
      fettling_status: 'Pending',
      quality_status: 'Pending', // Overall QC
      painting_status: 'Pending',
      date_moulded: new Date().toISOString().split('T')[0],
      shift,
      worker_details
    });
    createdCastings.push(casting);
  }

  // Update Work Order produced qty
  const wo = db.getById('work_orders', plan.work_order_id);
  if (wo) {
    db.update('work_orders', plan.work_order_id, {
      produced_qty: (wo.produced_qty || 0) + Number(qty_cast),
      status: 'In Production'
    });
  }

  res.status(201).json({
    success: true,
    message: `Recorded production of ${qty_cast} castings mapped to Heat ${heat_id}.`,
    castings: createdCastings
  });
});


// --- QUALITY & IN-PROCESS CONTROL ---

// 10. First Stage Inspection (Post-Knockout)
app.post('/api/quality/knockout/inspect', (req, res) => {
  const { casting_ids, status, rejection_reason, root_cause_tag } = req.body; 
  // status: 'Accepted' or 'Rejected'
  
  if (!casting_ids || casting_ids.length === 0) {
    return res.status(400).json({ success: false, message: "Select at least one casting to inspect." });
  }

  casting_ids.forEach(id => {
    const casting = db.getById('castings', id);
    if (casting) {
      if (status === 'Accepted') {
        db.update('castings', id, {
          stage: 'Knockout Inspected',
          knockout_status: 'Accepted'
        });
      } else {
        db.update('castings', id, {
          stage: 'Knockout Rejected',
          knockout_status: 'Rejected',
          quality_status: 'Rejected'
        });
        
        // Log rejection
        db.insert('rejection_logs', {
          casting_id: id,
          heat_id: casting.heat_id,
          product_id: casting.product_id,
          stage: 'Knockout',
          reason: rejection_reason || "Moulding Defect",
          root_cause_tag: root_cause_tag || "Sand Consistency",
          date: new Date().toISOString().split('T')[0]
        });
      }
    }
  });

  res.json({ success: true, message: `Completed Knockout inspection for ${casting_ids.length} castings.` });
});

// 11. Mechanical Testing (Heat-Wise)
app.post('/api/quality/mechanical/test', (req, res) => {
  const { heat_id, tensile_strength, hardness_bhn, elongation_percent } = req.body;

  const heat = db.getById('melting_heats', heat_id);
  if (!heat) {
    return res.status(404).json({ success: false, message: "Heat record not found." });
  }

  const grade = db.getById('grades', heat.grade_id);
  if (!grade) {
    return res.status(404).json({ success: false, message: "Grade specifications not found." });
  }

  // Verify against Grade Specs
  const failures = [];
  const spec = grade.mechanical;

  if (Number(tensile_strength) < spec.tensile_min) {
    failures.push(`Tensile Strength ${tensile_strength} MPa is below min ${spec.tensile_min} MPa.`);
  }
  if (spec.hardness_min && Number(hardness_bhn) < spec.hardness_min) {
    failures.push(`Hardness ${hardness_bhn} BHN is below min ${spec.hardness_min} BHN.`);
  }
  if (spec.hardness_max && Number(hardness_bhn) > spec.hardness_max) {
    failures.push(`Hardness ${hardness_bhn} BHN is above max ${spec.hardness_max} BHN.`);
  }
  if (spec.elongation_min && Number(elongation_percent) < spec.elongation_min) {
    failures.push(`Elongation ${elongation_percent}% is below min ${spec.elongation_min}%.`);
  }

  const pass = failures.length === 0;

  db.update('melting_heats', heat_id, {
    mechanical_status: pass ? 'Passed' : 'Failed'
  });

  // Log rejection context if failed
  if (!pass) {
    db.insert('rejection_logs', {
      casting_id: `HEAT-${heat_id}`,
      heat_id: heat_id,
      product_id: 'ALL',
      stage: 'Mechanical Test',
      reason: failures.join(' | '),
      root_cause_tag: 'Metallurgy Dev',
      date: new Date().toISOString().split('T')[0]
    });
  }

  res.json({
    success: true,
    passed: pass,
    failures,
    message: pass ? "Mechanical specifications verified. Passed." : "Mechanical specifications FAILED validation."
  });
});

// 12. Fettling Process
app.post('/api/quality/fettling/process', (req, res) => {
  const { casting_ids } = req.body;

  if (!casting_ids || casting_ids.length === 0) {
    return res.status(400).json({ success: false, message: "Select castings to move to Fettling." });
  }

  // Interlock: Only accepted castings from knockout allowed
  for (const id of casting_ids) {
    const casting = db.getById('castings', id);
    if (!casting) {
      return res.status(400).json({ success: false, message: `Casting ${id} does not exist.` });
    }
    if (casting.knockout_status !== 'Accepted') {
      return res.status(400).json({ success: false, message: `Casting ${id} cannot enter Fettling. It has not passed Knockout Stage inspection.` });
    }
  }

  casting_ids.forEach(id => {
    db.update('castings', id, {
      stage: 'Fettled',
      fettling_status: 'Processed'
    });
  });

  res.json({ success: true, message: `Moved ${casting_ids.length} castings into Fettled stage.` });
});

// 13. In-Process Inspection (Fettling Inspection)
app.post('/api/quality/fettling/inspect', (req, res) => {
  const { casting_ids, status, rejection_reason, root_cause_tag } = req.body;
  // status: 'Accepted', 'Rejected', 'Rework'

  if (!casting_ids || casting_ids.length === 0) {
    return res.status(400).json({ success: false, message: "Select castings to inspect." });
  }

  casting_ids.forEach(id => {
    const casting = db.getById('castings', id);
    if (casting) {
      if (status === 'Accepted') {
        db.update('castings', id, {
          stage: 'Fettling Inspected',
          quality_status: 'Accepted'
        });
      } else if (status === 'Rework') {
        db.update('castings', id, {
          stage: 'Knockout Inspected', // Reset to previous stage for rework
          fettling_status: 'Rework Required'
        });
      } else {
        db.update('castings', id, {
          stage: 'Fettling Rejected',
          quality_status: 'Rejected'
        });

        db.insert('rejection_logs', {
          casting_id: id,
          heat_id: casting.heat_id,
          product_id: casting.product_id,
          stage: 'Fettling',
          reason: rejection_reason || "Fettling Scar / Grinding Defect",
          root_cause_tag: root_cause_tag || "Worker Skill",
          date: new Date().toISOString().split('T')[0]
        });
      }
    }
  });

  res.json({ success: true, message: `Fettling inspection saved for ${casting_ids.length} castings.` });
});

// 14. Painting (Final Finishing)
app.post('/api/quality/painting/apply', (req, res) => {
  const { casting_ids } = req.body;

  if (!casting_ids || casting_ids.length === 0) {
    return res.status(400).json({ success: false, message: "Select castings to paint." });
  }

  // Interlock: Only approved castings (passed Fettling Inspection) move to painting
  for (const id of casting_ids) {
    const casting = db.getById('castings', id);
    if (!casting) {
      return res.status(400).json({ success: false, message: `Casting ${id} not found.` });
    }
    if (casting.quality_status !== 'Accepted') {
      return res.status(400).json({ success: false, message: `Casting ${id} cannot be painted. It must pass Fettling Quality Inspection first.` });
    }
  }

  casting_ids.forEach(id => {
    db.update('castings', id, {
      stage: 'Painted',
      painting_status: 'Approved'
    });
  });

  res.json({ success: true, message: `Completed painting for ${casting_ids.length} castings. Ready for Dispatch Clearance.` });
});


// --- DISPATCH MODULE ---

// Verification endpoint for dispatch clearance checking
app.get('/api/dispatch/clearance-check', (req, res) => {
  const { casting_ids } = req.query; // Query format: ?casting_ids=CAST-26-00001,CAST-26-00002
  
  if (!casting_ids) {
    return res.status(400).json({ success: false, message: "No casting IDs provided for verification." });
  }

  const ids = casting_ids.split(',');
  const results = [];
  let allClear = true;
  const reasonsBlocked = [];

  ids.forEach(id => {
    const casting = db.getById('castings', id);
    if (!casting) {
      allClear = false;
      reasonsBlocked.push(`Casting ID ${id} does not exist.`);
      return;
    }

    const heat = db.getById('melting_heats', casting.heat_id);
    if (!heat) {
      allClear = false;
      reasonsBlocked.push(`Heat records missing for Casting ${id}.`);
      return;
    }

    const checks = {
      id,
      heat_id: casting.heat_id,
      stage: casting.stage,
      chemical_passed: heat.chemical_status === 'Passed',
      mechanical_passed: heat.mechanical_status === 'Passed',
      painting_approved: casting.painting_status === 'Approved',
      is_rejected: casting.quality_status === 'Rejected' || casting.knockout_status === 'Rejected'
    };

    if (!checks.chemical_passed) {
      allClear = false;
      reasonsBlocked.push(`Casting ${id}: Pre-pour Chemical Test for Heat ${casting.heat_id} is Pending or Failed.`);
    }
    if (!checks.mechanical_passed) {
      allClear = false;
      reasonsBlocked.push(`Casting ${id}: Post-pour Mechanical Test for Heat ${casting.heat_id} is Pending or Failed.`);
    }
    if (!checks.painting_approved) {
      allClear = false;
      reasonsBlocked.push(`Casting ${id}: Painting/finishing process is not marked as Approved.`);
    }
    if (checks.is_rejected) {
      allClear = false;
      reasonsBlocked.push(`Casting ${id}: This casting has been marked as Rejected during QC inspections.`);
    }

    results.push(checks);
  });

  res.json({
    success: true,
    all_clear: allClear,
    block_reasons: reasonsBlocked,
    details: results
  });
});

// Create Dispatch Memo
app.post('/api/dispatch/memo', (req, res) => {
  const { customer_id, dispatch_items } = req.body; 
  // dispatch_items: [{ casting_id }]

  if (!dispatch_items || dispatch_items.length === 0) {
    return res.status(400).json({ success: false, message: "Dispatch items cannot be empty." });
  }

  // Interlock Verification: Dispatch NOT allowed if any QC stage pending or rejections not cleared
  const castingIds = dispatch_items.map(item => item.casting_id);
  const reasonsBlocked = [];
  let hasFailures = false;

  castingIds.forEach(id => {
    const casting = db.getById('castings', id);
    if (!casting) {
      hasFailures = true;
      reasonsBlocked.push(`Casting ${id} does not exist in system.`);
      return;
    }
    const heat = db.getById('melting_heats', casting.heat_id);
    
    if (casting.stage !== 'Painted' || casting.painting_status !== 'Approved') {
      hasFailures = true;
      reasonsBlocked.push(`Casting ${id}: Not fully finished/approved (Current Stage: ${casting.stage}).`);
    }
    if (!heat || heat.chemical_status !== 'Passed') {
      hasFailures = true;
      reasonsBlocked.push(`Casting ${id}: Heat ${casting.heat_id} chemical test is NOT passed.`);
    }
    if (!heat || heat.mechanical_status !== 'Passed') {
      hasFailures = true;
      reasonsBlocked.push(`Casting ${id}: Heat ${casting.heat_id} mechanical test is NOT passed.`);
    }
  });

  if (hasFailures) {
    return res.status(400).json({
      success: false,
      message: "Dispatch Interlock Blocked: Casting items do not meet dispatch criteria.",
      errors: reasonsBlocked
    });
  }

  // Calculate Net/Gross weights, grades, and fetch Heat IDs
  let totalWeight = 0;
  const heats = new Set();
  const castingProducts = new Set();

  castingIds.forEach(id => {
    const casting = db.getById('castings', id);
    const product = db.getById('products', casting.product_id);
    if (product) totalWeight += product.net_weight;
    heats.add(casting.heat_id);
    castingProducts.add(casting.product_id);
  });

  const customer = db.getById('customers', customer_id);

  // Generate Dispatch Memo
  const newMemo = db.insert('dispatch_memos', {
    customer_id,
    customer_name: customer ? customer.name : "Unknown Customer",
    date: new Date().toISOString().split('T')[0],
    casting_ids: castingIds,
    heat_nos: Array.from(heats),
    quantity: castingIds.length,
    weight_kg: totalWeight,
    test_certificate_status: 'Generated',
    qr_code_token: `M-${Date.now()}-${customer_id}`, // Secure QR code identifier
    status: 'Dispatched'
  });

  // Update Castings to Dispatched
  castingIds.forEach(id => {
    db.update('castings', id, { stage: 'Dispatched' });
  });

  // Update Work Order dispatch quantites
  castingIds.forEach(id => {
    const casting = db.getById('castings', id);
    const plan = db.getById('production_plans', casting.plan_id);
    if (plan && plan.work_order_id) {
      const wo = db.getById('work_orders', plan.work_order_id);
      if (wo) {
        db.update('work_orders', plan.work_order_id, {
          dispatched_qty: (wo.dispatched_qty || 0) + 1,
          status: (wo.dispatched_qty + 1) >= wo.quantity ? 'Completed' : 'Partially Dispatched'
        });
      }
    }
  });

  res.status(201).json({
    success: true,
    message: "Dispatch Memo successfully finalized. Castings set to 'Dispatched'.",
    data: newMemo
  });
});


// --- TRACEABILITY & ANALYTICS ---

// Full backward-forward traceability explorer
app.get('/api/traceability/search', (req, res) => {
  const { query } = req.query; // Heat No or Casting Serial No or PO No
  if (!query) return res.status(400).json({ message: "Search query required" });

  const upperQuery = query.toUpperCase();
  const castings = db.getAll('castings');
  const heats = db.getAll('melting_heats');
  const pos = db.getAll('purchase_orders');
  const wos = db.getAll('work_orders');
  const plans = db.getAll('production_plans');
  const memos = db.getAll('dispatch_memos');

  // Case 1: Search by Casting ID
  const matchedCasting = castings.find(c => c.id.toUpperCase() === upperQuery);
  if (matchedCasting) {
    const heat = heats.find(h => h.id === matchedCasting.heat_id);
    const plan = plans.find(p => p.id === matchedCasting.plan_id);
    const wo = plan ? wos.find(w => w.id === plan.work_order_id) : null;
    const po = wo ? pos.find(p => p.id === wo.po_id) : null;
    const memo = memos.find(m => m.casting_ids.includes(matchedCasting.id));
    const rawMaterials = db.getAll('melting_log_materials').filter(m => m.heat_id === matchedCasting.heat_id);
    const chemTest = db.getAll('chemical_tests').find(c => c.heat_id === matchedCasting.heat_id);

    return res.json({
      type: "Casting",
      item: matchedCasting,
      ancestry: {
        heat,
        plan,
        work_order: wo,
        purchase_order: po,
        dispatch_memo: memo,
        raw_materials: rawMaterials,
        chemical_test: chemTest
      }
    });
  }

  // Case 2: Search by Heat ID
  const matchedHeat = heats.find(h => h.id.toUpperCase() === upperQuery);
  if (matchedHeat) {
    const heatCastings = castings.filter(c => c.heat_id === matchedHeat.id);
    const rawMaterials = db.getAll('melting_log_materials').filter(m => m.heat_id === matchedHeat.id);
    const chemTest = db.getAll('chemical_tests').find(c => c.heat_id === matchedHeat.id);
    const matchingMemos = memos.filter(m => m.heat_nos.includes(matchedHeat.id));

    return res.json({
      type: "Heat",
      item: matchedHeat,
      ancestry: {
        castings: heatCastings,
        raw_materials: rawMaterials,
        chemical_test: chemTest,
        dispatch_memos: matchingMemos
      }
    });
  }

  // Case 3: Search by PO Number
  const matchedPO = pos.find(p => p.po_number.toUpperCase() === upperQuery);
  if (matchedPO) {
    const poWOs = wos.filter(w => w.po_id === matchedPO.id);
    const poPlans = plans.filter(p => poWOs.some(w => w.id === p.work_order_id));
    const poCastings = castings.filter(c => poPlans.some(p => p.id === c.plan_id));

    return res.json({
      type: "PO",
      item: matchedPO,
      ancestry: {
        work_orders: poWOs,
        plans: poPlans,
        castings: poCastings
      }
    });
  }

  res.status(404).json({ message: "No traceability link found matching query." });
});

// Rejection Analysis Data
app.get('/api/analytics/rejections', (req, res) => {
  const logs = db.getAll('rejection_logs');
  res.json(logs);
});

// Yield & Heat Efficiency Analytics
app.get('/api/analytics/yield', (req, res) => {
  const heats = db.getAll('melting_heats');
  const logs = db.getAll('melting_log_materials');
  const castings = db.getAll('castings');
  const products = db.getAll('products');

  const stats = heats.map(h => {
    // Total raw material input for this heat
    const heatMaterials = logs.filter(l => l.heat_id === h.id);
    const totalInputKg = heatMaterials.reduce((sum, item) => sum + item.qty_kg, 0);

    // Output castings Net weight
    const heatCastings = castings.filter(c => c.heat_id === h.id && c.quality_status === 'Accepted');
    const totalOutputKg = heatCastings.reduce((sum, c) => {
      const prod = products.find(p => p.id === c.product_id);
      return sum + (prod ? prod.net_weight : 0);
    }, 0);

    const yieldPercent = totalInputKg > 0 ? (totalOutputKg / totalInputKg) * 100 : 0;
    // Efficiency: Target vs actual scrap ratio. Let's make a mock calculation based on chemistry pass
    const efficiency = h.chemical_status === 'Passed' ? 92.5 : 68.0;

    return {
      heat_id: h.id,
      grade_name: h.grade_name,
      date: h.heat_date,
      input_kg: totalInputKg,
      output_kg: totalOutputKg,
      yield_percent: Number(yieldPercent.toFixed(2)),
      efficiency_percent: efficiency
    };
  });

  res.json(stats);
});

// --- SERVE STATIC FRONTEND ---
app.use(express.static(path.join(__dirname, 'dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`Foundry MIS Backend running on port ${PORT}`);
});

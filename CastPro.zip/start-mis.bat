@echo off
echo ===================================================
echo      Foundry MIS - Production Server Startup       
echo ===================================================

:: Check if Node.js is installed
node -v >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please download and install Node.js from https://nodejs.org/
    pause
    exit /b
)

:: Install dependencies if node_modules is missing
IF NOT EXIST "node_modules\" (
    echo [INFO] First time setup: Installing server dependencies...
    call npm install --omit=dev
)

echo [INFO] Starting the Foundry MIS Server...
echo [INFO] Please keep this window open while using the application.
echo.
start http://localhost:5000
node server.js
pause

import React, { useState, useEffect } from 'react';
import { Calendar, Flame, AlertCircle, RefreshCw, BarChart2, ShieldAlert } from 'lucide-react';

export default function Production({ addToast }) {
  const [activeProdTab, setActiveProdTab] = useState('planning');

  // Transaction Lists
  const [wos, setWOs] = useState([]);
  const [plans, setPlans] = useState([]);
  const [heats, setHeats] = useState([]);
  const [grades, setGrades] = useState([]);
  const [materials, setMaterials] = useState([]);

  // Form States
  const [planForm, setPlanForm] = useState({ wo_id: '', qty: 50, date: '', line: 'Line-A (DISAMATIC)', capacity: 10 });
  const [heatForm, setHeatForm] = useState({ grade_id: '', furnace: 'Inductotherm-3T', date: '', pig_iron: 500, scrap: 800, silicon: 50, manganese: 30, magnesium: 10 });
  const [chemForm, setChemForm] = useState({ heat_id: '', C: 3.25, Si: 1.95, Mn: 0.72, S: 0.045, P: 0.035, Mg: 0.0 });
  const [execForm, setExecForm] = useState({ plan_id: '', heat_id: '', qty_cast: 50, shift: 'Shift-A', worker: 'Ramesh Patel' });

  // Selected Grade Specs Cache (for Chem Testing UI warning calculations)
  const [selectedGradeSpecs, setSelectedGradeSpecs] = useState(null);
  const [chemDeviations, setChemDeviations] = useState([]);

  useEffect(() => {
    loadMasters();
    loadTransactions();
  }, [activeProdTab]);

  useEffect(() => {
    calculateChemDeviations();
  }, [chemForm, selectedGradeSpecs]);

  const loadMasters = async () => {
    try {
      const resGrades = await fetch('/api/masters/grades');
      const resMats = await fetch('/api/masters/inventory');
      if (resGrades.ok) setGrades(await resGrades.json());
      if (resMats.ok) setMaterials(await resMats.json());
    } catch (err) {
      console.warn("Offline fallback for production master files");
    }
  };

  const loadTransactions = async () => {
    try {
      const resWO = await fetch('/api/masters/work_orders');
      const resPlan = await fetch('/api/masters/production_plans');
      const resHeat = await fetch('/api/masters/melting_heats');
      if (resWO.ok) setWOs(await resWO.json());
      if (resPlan.ok) setPlans(await resPlan.json());
      if (resHeat.ok) setHeats(await resHeat.json());
    } catch (err) {
      console.warn("Offline fallback for transactions loading");
    }
  };

  const handlePlanSubmit = async (e) => {
    e.preventDefault();
    if (!planForm.wo_id) {
      addToast("Interlock Triggered: Work Order selection is mandatory to schedule a production plan.", "error");
      return;
    }

    try {
      const res = await fetch('/api/production/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          work_order_id: planForm.wo_id,
          planned_qty: Number(planForm.qty),
          planned_date: planForm.date,
          moulding_line: planForm.line,
          core_box_details: "Shell Core Box No 4",
          machine_capacity_tons: Number(planForm.capacity)
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Production plan scheduled and mapped successfully.`, "success");
        loadTransactions();
        setActiveProdTab('melting');
      } else {
        addToast(data.message || "Failed to schedule plan.");
      }
    } catch (err) {
      addToast("Server offline. Mocking production plan scheduling.", "success");
      const mockId = `PLN-26000${plans.length + 1}`;
      const woObj = wos.find(w => w.id === planForm.wo_id) || { po_number: 'PO-99', product_id: 'PROD001', product_name: 'Flywheel Housing', grade_id: 'GR_FG260', grade_name: 'FG260' };
      const newPlan = {
        id: mockId,
        work_order_id: planForm.wo_id,
        po_number: woObj.po_number,
        product_id: woObj.product_id,
        product_name: woObj.product_name,
        grade_id: woObj.grade_id,
        grade_name: woObj.grade_name,
        planned_qty: planForm.qty,
        planned_date: planForm.date,
        moulding_line: planForm.line,
        status: 'Planned'
      };
      setPlans(prev => [...prev, newPlan]);
      setActiveProdTab('melting');
    }
  };

  const handleHeatSubmit = async (e) => {
    e.preventDefault();
    if (!heatForm.grade_id) {
      addToast("Interlock: A design Grade mapping is required to initialize a furnace Heat log.", "error");
      return;
    }

    // Set up material loading inputs list
    const materialsInput = [
      { material_id: 'INV001', qty_kg: Number(heatForm.pig_iron) },
      { material_id: 'INV002', qty_kg: Number(heatForm.scrap) },
      { material_id: 'INV003', qty_kg: Number(heatForm.silicon) },
      { material_id: 'INV004', qty_kg: Number(heatForm.manganese) }
    ];
    if (Number(heatForm.magnesium) > 0) {
      materialsInput.push({ material_id: 'INV005', qty_kg: Number(heatForm.magnesium) });
    }

    try {
      const res = await fetch('/api/production/heat/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          furnace_id: heatForm.furnace,
          grade_id: heatForm.grade_id,
          heat_date: heatForm.date,
          materials_input: materialsInput
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Furnace Heat ${data.data.id} initiated. Chemical pre-pour test required.`, "success");
        loadTransactions();
        setActiveProdTab('chemical');
      } else {
        addToast(data.message || "Failed to initiate heat.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Furnace Heat initiation.", "success");
      const mockId = `HEAT-2600${heats.length + 1}`;
      const grade = grades.find(g => g.id === heatForm.grade_id) || { name: 'FG260 Grey Iron' };
      const newHeat = {
        id: mockId,
        furnace_id: heatForm.furnace,
        grade_id: heatForm.grade_id,
        grade_name: grade.name,
        heat_date: heatForm.date,
        chemical_status: 'Pending Testing',
        mechanical_status: 'Pending Testing',
        materials_deducted: false,
        status: 'Pouring Blocked'
      };
      setHeats(prev => [...prev, newHeat]);
      setActiveProdTab('chemical');
    }
  };

  const handleHeatSelect = (heatId) => {
    setChemForm({ ...chemForm, heat_id: heatId });
    const targetHeat = heats.find(h => h.id === heatId);
    if (targetHeat) {
      const targetGrade = grades.find(g => g.id === targetHeat.grade_id);
      setSelectedGradeSpecs(targetGrade || null);
    } else {
      setSelectedGradeSpecs(null);
    }
  };

  const calculateChemDeviations = () => {
    if (!selectedGradeSpecs) {
      setChemDeviations([]);
      return;
    }
    const specs = selectedGradeSpecs.chemical;
    const deviations = [];
    
    for (const el in specs) {
      const val = Number(chemForm[el] || 0);
      const min = specs[el].min;
      const max = specs[el].max;
      if (val < min || val > max) {
        deviations.push(`${el}: ${val}% is out of grade range [${min}% - ${max}%]`);
      }
    }
    setChemDeviations(deviations);
  };

  const handleChemicalSubmit = async (e) => {
    e.preventDefault();
    if (!chemForm.heat_id) {
      addToast("Select an active Heat ID.", "error");
      return;
    }

    try {
      const res = await fetch('/api/production/chemical/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          heat_id: chemForm.heat_id,
          chemistry_readings: {
            C: Number(chemForm.C),
            Si: Number(chemForm.Si),
            Mn: Number(chemForm.Mn),
            S: Number(chemForm.S),
            P: Number(chemForm.P),
            Mg: Number(chemForm.Mg)
          }
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.passed) {
          addToast("Chemical specifications PASSED! Pouring approved.", "success");
          loadTransactions();
          setActiveProdTab('execution');
        } else {
          addToast("INTERLOCK FAILED: Chemistry does not meet Grade targets! Pouring is blocked.", "error");
          loadTransactions();
        }
      } else {
        addToast(data.message || "Chemical logging failed.");
      }
    } catch (err) {
      addToast("Server offline. Mock verifying chemistry readings.", "success");
      // Simulate pass/fail check offline
      const pass = chemDeviations.length === 0;
      setHeats(prev => prev.map(h => h.id === chemForm.heat_id ? {
        ...h,
        chemical_status: pass ? 'Passed' : 'Failed',
        status: pass ? 'Pouring Approved' : 'Pouring Blocked'
      } : h));
      if (pass) {
        setActiveProdTab('execution');
      }
    }
  };

  const handleExecutionSubmit = async (e) => {
    e.preventDefault();
    if (!execForm.plan_id || !execForm.heat_id) {
      addToast("Production Plan and Heat No. are mandatory references.", "error");
      return;
    }

    const heat = heats.find(h => h.id === execForm.heat_id);
    if (heat && heat.chemical_status !== 'Passed') {
      addToast(`INTERLOCK BLOCKED: Chemistry for Heat ${execForm.heat_id} is ${heat.chemical_status}. Pouring is blocked.`, "error");
      return;
    }

    try {
      const res = await fetch('/api/production/execution/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan_id: execForm.plan_id,
          heat_id: execForm.heat_id,
          qty_cast: Number(execForm.qty_cast),
          shift: execForm.shift,
          worker_details: execForm.worker
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Casting Serial logs created for ${execForm.qty_cast} castings. Mapped to Heat ${execForm.heat_id}.`, "success");
        loadTransactions();
        setActiveProdTab('closure');
      } else {
        addToast(data.message || "Failed to record execution.");
      }
    } catch (err) {
      addToast("Server offline. Mocking casting serialization.", "success");
      // Simulate castings update
      setActiveProdTab('closure');
    }
  };

  const handleCloseHeat = async (heatId) => {
    try {
      const res = await fetch('/api/production/heat/consume-and-close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ heat_id: heatId })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast("Heat Closed. Inventory stocks deducted successfully.", "success");
        if (data.alerts && data.alerts.length > 0) {
          data.alerts.forEach(al => addToast(al, "warning"));
        }
        loadTransactions();
      } else {
        addToast(data.message || "Failed to close heat.");
      }
    } catch (err) {
      addToast("Server offline. Mocking raw materials auto-deduction.", "success");
      setHeats(prev => prev.map(h => h.id === heatId ? { ...h, status: 'Completed', materials_deducted: true } : h));
      addToast("Inventory Warning: Safety Stock for Ferro-Silicon is critical!", "warning");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold text-white">Production & Execution</h1>
          <p className="text-slate-400 text-sm mt-1">Foundry melting log control, chemical spec gates and moulding entries.</p>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-lg">
          {['planning', 'melting', 'chemical', 'execution', 'closure'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveProdTab(tab)}
              className={`px-3 py-1.5 text-xs font-bold rounded uppercase tracking-wider transition-all ${activeProdTab === tab ? 'bg-orange-500 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: Input Form */}
        <div className="glass-card col-span-1 lg:col-span-2">
          
          {/* TAB 1: PRODUCTION PLANNING */}
          {activeProdTab === 'planning' && (
            <form onSubmit={handlePlanSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-orange-500" /> Step 5: Plan Moulding Job
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Reference Work Order</label>
                  <select className="form-control" required value={planForm.wo_id} onChange={e=>setPlanForm({...planForm, wo_id: e.target.value})}>
                    <option value="">-- Select Active Work Order --</option>
                    {wos.filter(w=>w.status !== 'Completed').map(w => (
                      <option key={w.id} value={w.id}>{w.id} - {w.product_name} ({w.quantity} units)</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Planned Mould Quantity (nos)</label>
                  <input type="number" className="form-control" required value={planForm.qty} onChange={e=>setPlanForm({...planForm, qty: e.target.value})} />
                </div>
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Moulding Line & Machine</label>
                  <select className="form-control" value={planForm.line} onChange={e=>setPlanForm({...planForm, line: e.target.value})}>
                    <option value="Line-A (DISAMATIC)">Line-A (DISAMATIC Vertical)</option>
                    <option value="Line-B (ARPA-450)">Line-B (ARPA-450 Jolt Squeeze)</option>
                    <option value="Hand-Moulding Shop">Hand-Moulding Shop (No-Bake Sand)</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Line Capacity Limit (Tons Load)</label>
                  <input type="number" className="form-control" required value={planForm.capacity} onChange={e=>setPlanForm({...planForm, capacity: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Scheduled Date</label>
                  <input type="date" className="form-control" required value={planForm.date} onChange={e=>setPlanForm({...planForm, date: e.target.value})} />
                </div>
              </div>

              <button type="submit" className="btn btn-primary">Schedule Moulding Job</button>
            </form>
          )}

          {/* TAB 2: MELTING & HEAT LOG */}
          {activeProdTab === 'melting' && (
            <form onSubmit={handleHeatSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-500" /> Step 6: Melt Heat & Raw Materials Input
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Design Grade standard</label>
                  <select className="form-control" required value={heatForm.grade_id} onChange={e=>setHeatForm({...heatForm, grade_id: e.target.value})}>
                    <option value="">-- Choose Grade mapping --</option>
                    {grades.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Furnace ID Selection</label>
                  <select className="form-control" value={heatForm.furnace} onChange={e=>setHeatForm({...heatForm, furnace: e.target.value})}>
                    <option value="Inductotherm-3T">Inductotherm 3 Ton Induction</option>
                    <option value="Furnace-B-1T">1 Ton Medium Freq Crucible</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Melting Date</label>
                  <input type="date" className="form-control" required value={heatForm.date} onChange={e=>setHeatForm({...heatForm, date: e.target.value})} />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                <h4 className="font-bold text-xs text-orange-400 uppercase tracking-wider mb-3">Furnace Recipe Loading (kg)</h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Pig Iron</label>
                    <input type="number" className="form-control mt-1 py-1 text-xs" value={heatForm.pig_iron} onChange={e=>setHeatForm({...heatForm, pig_iron: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Steel Scrap</label>
                    <input type="number" className="form-control mt-1 py-1 text-xs" value={heatForm.scrap} onChange={e=>setHeatForm({...heatForm, scrap: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Ferro-Silicon</label>
                    <input type="number" className="form-control mt-1 py-1 text-xs" value={heatForm.silicon} onChange={e=>setHeatForm({...heatForm, silicon: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Ferro-Mn</label>
                    <input type="number" className="form-control mt-1 py-1 text-xs" value={heatForm.manganese} onChange={e=>setHeatForm({...heatForm, manganese: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Magnesium</label>
                    <input type="number" className="form-control mt-1 py-1 text-xs" value={heatForm.magnesium} onChange={e=>setHeatForm({...heatForm, magnesium: e.target.value})} />
                  </div>
                </div>
              </div>

              <button type="submit" className="btn btn-primary">Load Raw Materials & Start Melt</button>
            </form>
          )}

          {/* TAB 3: CHEMICAL PRE-POUR TEST */}
          {activeProdTab === 'chemical' && (
            <form onSubmit={handleChemicalSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-orange-500" /> Step 7: Pre-Pour Spectro Chemical Analysis
              </h3>

              <div className="form-group max-w-sm">
                <label className="form-label">Select Active Furnace Heat No</label>
                <select className="form-control" required value={chemForm.heat_id} onChange={e=>handleHeatSelect(e.target.value)}>
                  <option value="">-- Choose Active Heat --</option>
                  {heats.filter(h => h.status === 'Pouring Blocked' || h.chemical_status === 'Pending Testing').map(h => (
                    <option key={h.id} value={h.id}>{h.id} ({h.grade_name})</option>
                  ))}
                </select>
              </div>

              {selectedGradeSpecs && (
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4 fade-in">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-xs text-orange-400 uppercase tracking-wider">Specs Comparison: {selectedGradeSpecs.name}</h4>
                    <span className="text-[10px] text-slate-400 font-mono">Elements Range (%)</span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500">C % (Target: {selectedGradeSpecs.chemical.C.min}-{selectedGradeSpecs.chemical.C.max})</label>
                      <input type="number" step="0.01" className="form-control mt-1 text-sm" value={chemForm.C} onChange={e=>setChemForm({...chemForm, C: e.target.value})} />
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500">Si % (Target: {selectedGradeSpecs.chemical.Si.min}-{selectedGradeSpecs.chemical.Si.max})</label>
                      <input type="number" step="0.01" className="form-control mt-1 text-sm" value={chemForm.Si} onChange={e=>setChemForm({...chemForm, Si: e.target.value})} />
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500">Mn % (Target: {selectedGradeSpecs.chemical.Mn.min}-{selectedGradeSpecs.chemical.Mn.max})</label>
                      <input type="number" step="0.01" className="form-control mt-1 text-sm" value={chemForm.Mn} onChange={e=>setChemForm({...chemForm, Mn: e.target.value})} />
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500">S % (Max: {selectedGradeSpecs.chemical.S.max})</label>
                      <input type="number" step="0.001" className="form-control mt-1 text-sm" value={chemForm.S} onChange={e=>setChemForm({...chemForm, S: e.target.value})} />
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500">P % (Max: {selectedGradeSpecs.chemical.P.max})</label>
                      <input type="number" step="0.001" className="form-control mt-1 text-sm" value={chemForm.P} onChange={e=>setChemForm({...chemForm, P: e.target.value})} />
                    </div>
                  </div>

                  {chemDeviations.length > 0 ? (
                    <div className="deviation-warning flex items-start gap-2">
                      <ShieldAlert className="w-5 h-5 flex-shrink-0 text-red-400 mt-0.5" />
                      <div>
                        <h5 className="font-bold text-sm text-red-300">Out-Of-Spec Chemical Deviations Detected</h5>
                        <ul className="list-disc pl-5 mt-1 text-xs space-y-1 text-red-200">
                          {chemDeviations.map((dev, idx) => <li key={idx}>{dev}</li>)}
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-lg text-emerald-400 text-xs font-semibold flex items-center gap-2">
                      ✓ Spec Chemistry targets matched. Pouring is safe.
                    </div>
                  )}
                </div>
              )}

              <button type="submit" className="btn btn-primary" disabled={!chemForm.heat_id}>Verify & Approve Pouring</button>
            </form>
          )}

          {/* TAB 4: PRODUCTION EXECUTION */}
          {activeProdTab === 'execution' && (
            <form onSubmit={handleExecutionSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-500" /> Step 8: Pour Execution & Moulding Entry
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Moulding Production Schedule Plan</label>
                  <select className="form-control" required value={execForm.plan_id} onChange={e=>setExecForm({...execForm, plan_id: e.target.value})}>
                    <option value="">-- Choose Active Plan --</option>
                    {plans.map(p => (
                      <option key={p.id} value={p.id}>{p.id} - {p.product_name} (Planned: {p.planned_qty})</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Assigned Melting Heat No (Approved Chem)</label>
                  <select className="form-control" required value={execForm.heat_id} onChange={e=>setExecForm({...execForm, heat_id: e.target.value})}>
                    <option value="">-- Select Chemistry Approved Heat --</option>
                    {heats.map(h => (
                      <option key={h.id} value={h.id}>{h.id} ({h.grade_name}) - status: {h.chemical_status}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Actual Quantity Cast (nos)</label>
                  <input type="number" className="form-control" required value={execForm.qty_cast} onChange={e=>setExecForm({...execForm, qty_cast: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Shift Details</label>
                  <select className="form-control" value={execForm.shift} onChange={e=>setExecForm({...execForm, shift: e.target.value})}>
                    <option value="Shift-A">Shift-A (06:00 AM - 02:00 PM)</option>
                    <option value="Shift-B">Shift-B (02:00 PM - 10:00 PM)</option>
                    <option value="Shift-C">Shift-C (10:00 PM - 06:00 AM)</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Operator / Ladleman Name</label>
                  <input type="text" className="form-control" value={execForm.worker} onChange={e=>setExecForm({...execForm, worker: e.target.value})} />
                </div>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <p className="text-[11px] text-slate-500">
                  <strong>Traceability interlock note:</strong> Submitting this entry serializes and seals every single casting poured under this unique Heat number. This enables full backward search tracking later.
                </p>
              </div>

              <button type="submit" className="btn btn-primary">Record Poured Castings</button>
            </form>
          )}

          {/* TAB 5: HEAT CLOSURE & MATERIAL AUTO DEDUCTION */}
          {activeProdTab === 'closure' && (
            <div className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-500" /> Step 9: Melting Heat Closure & Stock Deduction
              </h3>
              
              <div className="table-container">
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th>Heat ID</th>
                      <th>Grade Standard</th>
                      <th>Heat Date</th>
                      <th>Chemical</th>
                      <th>Inventory Deducted</th>
                      <th>Action Button</th>
                    </tr>
                  </thead>
                  <tbody>
                    {heats.map(h => (
                      <tr key={h.id}>
                        <td className="font-mono text-xs font-bold text-white">{h.id}</td>
                        <td className="text-slate-200">{h.grade_name}</td>
                        <td>{h.heat_date}</td>
                        <td>
                          <span className={`badge ${h.chemical_status === 'Passed' ? 'badge-success' : 'badge-danger'}`}>{h.chemical_status}</span>
                        </td>
                        <td>
                          <span className={`badge ${h.materials_deducted ? 'badge-success' : 'badge-warning'}`}>
                            {h.materials_deducted ? 'Deducted' : 'Pending'}
                          </span>
                        </td>
                        <td>
                          <button 
                            disabled={h.materials_deducted} 
                            onClick={() => handleCloseHeat(h.id)} 
                            className="btn btn-secondary py-1 text-xs"
                          >
                            Close Heat & Deduct Stock
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Database monitors */}
        <div className="glass-card col-span-1 border-slate-800 bg-slate-950/20">
          <h3 className="font-bold text-white text-base border-b border-slate-800 pb-2 mb-3">
            Active Furnace Heat Logs
          </h3>

          <div className="space-y-3 overflow-y-auto max-h-[480px]">
            {heats.map(h => (
              <div key={h.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-mono text-xs text-orange-500 font-bold">{h.id}</span>
                  <span className={`badge ${h.status === 'Completed' ? 'badge-success' : h.status === 'Pouring Approved' ? 'badge-info' : 'badge-danger'}`}>
                    {h.status}
                  </span>
                </div>
                <h4 className="font-bold text-xs text-white mt-1">{h.grade_name}</h4>
                <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
                  <div>Date: <span className="text-white">{h.heat_date}</span></div>
                  <div>Furnace: <span className="text-white font-mono">{h.furnace_id}</span></div>
                  <div>Chemistry: <span className={h.chemical_status === 'Passed' ? 'text-emerald-400 font-bold' : 'text-amber-500 font-bold'}>{h.chemical_status}</span></div>
                  <div>Inventory: <span className={h.materials_deducted ? 'text-emerald-400 font-bold' : 'text-amber-500'}>{h.materials_deducted ? 'Closed' : 'Open'}</span></div>
                </div>
              </div>
            ))}
            {heats.length === 0 && (
              <p className="text-slate-600 text-center py-10 text-xs">No active Heats found in system logs.</p>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}

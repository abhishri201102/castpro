import React, { useState, useEffect, useRef } from 'react';
import { ShieldCheck, ShieldAlert, QrCode, Search, FileText, Printer, ArrowRight, GitCommit } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

export default function DispatchTraceability({ addToast }) {
  const [activeTab, setActiveTab] = useState('clearance');

  // Directory states
  const [customers, setCustomers] = useState([]);
  const [castings, setCastings] = useState([]);
  const [memos, setMemos] = useState([]);

  // Clearance Check states
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedCastings, setSelectedCastings] = useState([]);
  const [clearanceResult, setClearanceResult] = useState(null);
  const [checkingClearance, setCheckingClearance] = useState(false);

  // Active Memo Viewer
  const [activeMemo, setActiveMemo] = useState(null);

  // Traceability Search states
  const [searchQuery, setSearchQuery] = useState('CAST-26-00001');
  const [traceResult, setTraceResult] = useState(null);
  const [traceError, setTraceError] = useState('');

  const printRef = useRef();

  useEffect(() => {
    loadMasters();
    loadTransactions();
  }, [activeTab]);

  const loadMasters = async () => {
    try {
      const res = await fetch('/api/masters/customers');
      if (res.ok) setCustomers(await res.json());
    } catch (err) {
      console.warn("Offline fallback for dispatch customers");
    }
  };

  const loadTransactions = async () => {
    try {
      const resCast = await fetch('/api/masters/castings');
      const resMemo = await fetch('/api/masters/dispatch_memos');
      if (resCast.ok) setCastings(await resCast.json());
      if (resMemo.ok) setMemos(await resMemo.json());
    } catch (err) {
      console.warn("Offline fallback for dispatch lists");
      // Mocks for local display
      setCastings([
        { id: 'CAST-26-00003', heat_id: 'HEAT-26001', product_name: 'Flywheel Housing', stage: 'Painted', painting_status: 'Approved' },
        { id: 'CAST-26-00005', heat_id: 'HEAT-26002', product_name: 'Crankshaft 4-Cyl', stage: 'Painted', painting_status: 'Approved' }
      ]);
    }
  };

  const handleSelectionToggle = (id) => {
    setSelectedCastings(prev => 
      prev.includes(id) ? prev.filter(cId => cId !== id) : [...prev, id]
    );
    setClearanceResult(null);
  };

  // Run Interlocking Verification check before dispatching
  const runClearanceCheck = async () => {
    if (selectedCastings.length === 0) {
      addToast("Select castings to run dispatch clearance check.", "error");
      return;
    }
    setCheckingClearance(true);
    try {
      const res = await fetch(`/api/dispatch/clearance-check?casting_ids=${selectedCastings.join(',')}`);
      if (res.ok) {
        const data = await res.json();
        setClearanceResult(data);
      } else {
        const data = await res.json();
        addToast(data.message || "Failed clearance validation.");
      }
    } catch (err) {
      // Simulate clearance check offline (Let's make CAST-26-00003 pass and CAST-26-00005 fail due to mechanical spec)
      console.warn("Offline simulation for clearance validation");
      const hasFailure = selectedCastings.includes('CAST-26-00005');
      setClearanceResult({
        success: true,
        all_clear: !hasFailure,
        block_reasons: hasFailure ? [
          "Casting CAST-26-00005: Post-pour Mechanical Test for Heat HEAT-26002 is Pending or Failed."
        ] : [],
        details: selectedCastings.map(id => ({
          id,
          heat_id: id === 'CAST-26-00003' ? 'HEAT-26001' : 'HEAT-26002',
          stage: 'Painted',
          chemical_passed: true,
          mechanical_passed: id === 'CAST-26-00003',
          painting_approved: true,
          is_rejected: false
        }))
      });
    } finally {
      setCheckingClearance(false);
    }
  };

  // Generate Dispatch Memo
  const handleIssueMemo = async () => {
    if (!selectedCustomerId) {
      addToast("Please select customer details.", "error");
      return;
    }

    try {
      const res = await fetch('/api/dispatch/memo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: selectedCustomerId,
          dispatch_items: selectedCastings.map(id => ({ casting_id: id }))
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast("Dispatch Memo issued. Inventory updated.", "success");
        setClearanceResult(null);
        setSelectedCastings([]);
        loadTransactions();
        setActiveTab('memos');
      } else {
        addToast(data.message || "Interlock Blocked Dispatch memo issuing.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Dispatch Memo Generation.", "success");
      const mockMemo = {
        id: `MEMO-2600${memos.length + 1}`,
        customer_id: selectedCustomerId,
        customer_name: customers.find(c=>c.id === selectedCustomerId)?.name || "Tata Motors",
        date: new Date().toISOString().split('T')[0],
        casting_ids: selectedCastings,
        heat_nos: ['HEAT-26001'],
        quantity: selectedCastings.length,
        weight_kg: selectedCastings.length * 32,
        test_certificate_status: 'Generated',
        qr_code_token: `M-${Date.now()}-${selectedCustomerId}`,
        status: 'Dispatched'
      };
      setMemos(prev => [...prev, mockMemo]);
      setSelectedCastings([]);
      setActiveTab('memos');
    }
  };

  // Traceability Ancestry Tree Search
  const handleTraceSearch = async (e) => {
    e.preventDefault();
    setTraceError('');
    setTraceResult(null);

    if (!searchQuery) return;

    try {
      const res = await fetch(`/api/traceability/search?query=${searchQuery}`);
      const data = await res.json();
      if (res.ok) {
        setTraceResult(data);
      } else {
        setTraceError(data.message || "Reference item not found in database registry.");
      }
    } catch (err) {
      // Offline fallback tracing map visual builder
      console.warn("Offline search mock");
      if (searchQuery.startsWith('CAST')) {
        setTraceResult({
          type: "Casting",
          item: { id: searchQuery, heat_id: 'HEAT-26001', product_name: 'Flywheel Housing', stage: 'Painted', date_moulded: '2026-05-25', shift: 'Shift-A', worker_details: 'Ramesh Patel' },
          ancestry: {
            heat: { id: 'HEAT-26001', furnace_id: 'Inductotherm-3T', grade_name: 'FG260 (Grey Iron)', heat_date: '2026-05-25', chemical_status: 'Passed', mechanical_status: 'Passed' },
            plan: { id: 'PLN-260001', planned_date: '2026-05-25', moulding_line: 'Line-A (DISAMATIC)' },
            work_order: { id: 'WO-260001', po_number: 'PO/TATA/998', quantity: 100 },
            purchase_order: { po_number: 'PO/TATA/998', customer_name: 'Tata Motors Ltd', date: '2026-05-20' },
            dispatch_memo: null,
            raw_materials: [
              { material_id: 'INV001', qty_kg: 500 },
              { material_id: 'INV002', qty_kg: 800 }
            ],
            chemical_test: {
              chemistry_readings: { C: 3.25, Si: 1.95, Mn: 0.72, S: 0.045, P: 0.035 }
            }
          }
        });
      } else {
        setTraceError("Search item not found. Try searching casting: 'CAST-26-00001'");
      }
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const clearedItems = castings.filter(c => c.stage === 'Painted' && c.painting_status === 'Approved');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold text-white">Dispatch & Traceability</h1>
          <p className="text-slate-400 text-sm mt-1">Checklist safety interlocks, printable test certificates and ancestry tracing.</p>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-lg">
          {['clearance', 'memos', 'traceability'].map(tab => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setActiveMemo(null);
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded uppercase tracking-wider transition-all ${activeTab === tab ? 'bg-orange-500 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              {tab === 'clearance' ? 'Safety Clearance' : tab === 'memos' ? 'Dispatch Memos' : 'Traceability Engine'}
            </button>
          ))}
        </div>
      </div>

      {/* VIEW 1: DISPATCH CLEARANCE GATE */}
      {activeTab === 'clearance' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="glass-card col-span-2 space-y-4">
            <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400 animate-pulse" /> Final Gate: Run Interlock Clearances
            </h3>

            <div className="form-group max-w-sm">
              <label className="form-label font-bold text-orange-400">Map Destination Customer</label>
              <select className="form-control" value={selectedCustomerId} onChange={e=>setSelectedCustomerId(e.target.value)}>
                <option value="">-- Choose Customer --</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>

            {/* List of castings ready (Painted and approved) */}
            <div className="table-container max-h-[300px] overflow-y-auto">
              <table className="custom-table">
                <thead>
                  <tr>
                    <th style={{ width: '40px' }}>Select</th>
                    <th>Casting ID</th>
                    <th>Heat ID</th>
                    <th>Product Model</th>
                    <th>Finished Stage</th>
                  </tr>
                </thead>
                <tbody>
                  {clearedItems.map(item => (
                    <tr key={item.id} className={selectedCastings.includes(item.id) ? 'bg-slate-900/60' : ''}>
                      <td>
                        <input 
                          type="checkbox" 
                          className="bg-slate-950 border-slate-800 rounded cursor-pointer"
                          checked={selectedCastings.includes(item.id)} 
                          onChange={() => handleSelectionToggle(item.id)} 
                        />
                      </td>
                      <td className="font-mono text-xs font-bold text-white">{item.id}</td>
                      <td className="font-mono text-xs text-slate-400">{item.heat_id}</td>
                      <td>{item.product_name}</td>
                      <td>
                        <span className="badge badge-success">Finished OK</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {clearedItems.length === 0 && (
                <p className="text-xs text-slate-500 text-center py-10">No finished castings ready for clearance testing in storage.</p>
              )}
            </div>

            {selectedCastings.length > 0 && (
              <div className="flex gap-3 pt-2">
                <button 
                  onClick={runClearanceCheck} 
                  className="btn btn-primary"
                  disabled={checkingClearance}
                >
                  Run Interlock Clearance check ({selectedCastings.length})
                </button>
              </div>
            )}
          </div>

          {/* RIGHT CHECKLIST PANEL */}
          <div className="glass-card col-span-1">
            <h3 className="font-bold text-white text-base border-b border-slate-800 pb-2 mb-4">Clearance Verifications</h3>

            {clearanceResult ? (
              <div className="space-y-4 fade-in">
                {clearanceResult.all_clear ? (
                  <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-lg text-emerald-400 text-xs font-semibold">
                    ✓ All interlocking validation gates matched. Casting lot is cleared for Dispatch.
                  </div>
                ) : (
                  <div className="deviation-warning flex items-start gap-2">
                    <ShieldAlert className="w-5 h-5 flex-shrink-0 text-red-400 mt-0.5" />
                    <div>
                      <h5 className="font-bold text-xs text-red-300">DISPATCH BLOCKED: QC DEVIATIONS</h5>
                      <ul className="list-disc pl-4 mt-1 text-[10px] space-y-1 text-red-200">
                        {clearanceResult.block_reasons.map((err, idx) => <li key={idx}>{err}</li>)}
                      </ul>
                    </div>
                  </div>
                )}

                <div className="space-y-2 border-t border-slate-800 pt-3">
                  <h4 className="font-bold text-xs text-slate-400 uppercase">Checklist Gates:</h4>
                  {clearanceResult.details.map((check, idx) => (
                    <div key={idx} className="p-2 rounded bg-slate-900 border border-slate-800 text-[11px] space-y-1">
                      <div className="font-mono font-bold text-white">{check.id} (Heat: {check.heat_id})</div>
                      <div className="flex justify-between">
                        <span>Pre-pour Chemistry:</span>
                        <span className={check.chemical_passed ? 'text-emerald-400 font-bold' : 'text-red-500 font-bold'}>{check.chemical_passed ? 'Passed' : 'Failed'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Mechanical Spec Labs:</span>
                        <span className={check.mechanical_passed ? 'text-emerald-400 font-bold' : 'text-red-500 font-bold'}>{check.mechanical_passed ? 'Passed' : 'Failed'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Painting & Inspection:</span>
                        <span className={check.painting_approved ? 'text-emerald-400' : 'text-amber-500'}>{check.painting_approved ? 'Finished' : 'Pending'}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <button 
                  disabled={!clearanceResult.all_clear || !selectedCustomerId} 
                  onClick={handleIssueMemo} 
                  className="w-full btn btn-success py-2 font-bold mt-2"
                >
                  Issue Dispatch Memo & Generate QR
                </button>
              </div>
            ) : (
              <p className="text-xs text-slate-500 text-center py-20">Select castings lot and run the clearance audit check.</p>
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: ACTIVE MEMOS & CERTIFICATES PRINT */}
      {activeTab === 'memos' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="glass-card col-span-1 border-slate-800 max-h-[500px] overflow-y-auto">
            <h3 className="font-bold text-white text-base border-b border-slate-800 pb-2 mb-3">Issued Memos</h3>
            <div className="space-y-2">
              {memos.map(memo => (
                <div 
                  key={memo.id} 
                  onClick={() => setActiveMemo(memo)}
                  className={`p-3 bg-slate-900 border rounded-lg cursor-pointer transition-all ${activeMemo?.id === memo.id ? 'border-orange-500 bg-slate-850' : 'border-slate-800 hover:border-slate-700'}`}
                >
                  <div className="flex justify-between items-center text-xs font-mono">
                    <span className="text-orange-400 font-bold">{memo.id}</span>
                    <span className="text-slate-500">{memo.date}</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-200 mt-1">{memo.customer_name}</h4>
                  <div className="flex justify-between items-center mt-2 text-[10px] text-slate-500">
                    <span>Lot Qty: {memo.quantity} nos</span>
                    <span>Wt: {memo.weight_kg} kg</span>
                  </div>
                </div>
              ))}
              {memos.length === 0 && <p className="text-xs text-slate-500 text-center py-20">No dispatch memos issued yet.</p>}
            </div>
          </div>

          <div className="glass-card col-span-2">
            {activeMemo ? (
              <div className="space-y-4 fade-in">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
                  <h3 className="font-bold text-white text-lg flex items-center gap-2">
                    <FileText className="w-5 h-5 text-orange-500" /> Dispatch Manifest
                  </h3>
                  <button onClick={handlePrint} className="btn btn-secondary py-1 px-3 text-xs flex items-center gap-1.5">
                    <Printer className="w-4 h-4" /> Print manifest & certificates
                  </button>
                </div>

                {/* Printable Manifest Section */}
                <div ref={printRef} className="print-area p-6 rounded-xl bg-slate-900 border border-slate-800 space-y-6">
                  <div className="flex justify-between items-start border-b border-slate-800 pb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-white">CastTrace Pro Foundry Ltd</h2>
                      <p className="text-xs text-slate-400 mt-0.5">Foundry dispatch warehouse, Gate No. 2</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-orange-500 font-mono">{activeMemo.id}</div>
                      <div className="text-xs text-slate-400 mt-0.5 font-mono">{activeMemo.date}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <h4 className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">Shipped Destination:</h4>
                      <p className="font-bold text-white text-sm mt-1">{activeMemo.customer_name}</p>
                      <p className="text-slate-500 mt-0.5">Custom mapping registry ID: {activeMemo.customer_id}</p>
                    </div>
                    <div className="flex justify-end gap-4">
                      <div>
                        <h4 className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">Lot stats:</h4>
                        <div className="mt-1"><span className="text-slate-500">Qty:</span> <span className="font-bold text-white">{activeMemo.quantity} pcs</span></div>
                        <div><span className="text-slate-500">Net Wt:</span> <span className="font-bold text-white">{activeMemo.weight_kg} kg</span></div>
                      </div>
                      <div className="p-1 bg-white rounded flex items-center justify-center">
                        <QRCodeSVG value={activeMemo.qr_code_token} size={64} level="M" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 border-t border-slate-800 pt-4">
                    <h4 className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">Poured Castings Serial Inventory:</h4>
                    <div className="flex flex-wrap gap-2 text-xs font-mono">
                      {activeMemo.casting_ids.map(id => (
                        <span key={id} className="px-2 py-0.5 rounded bg-slate-950 border border-slate-850 text-slate-300">{id}</span>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 rounded bg-slate-950/60 border border-slate-800 text-[10px] text-slate-500 space-y-1">
                    <h4 className="font-bold text-[10px] text-orange-500 uppercase tracking-wider mb-2">Automated Digital Mill Test Certificate verification</h4>
                    <p>✓ Microstructural, chemistry spectrometry analysis and tensile tests are interlocked. Pouring records verified.</p>
                    <p>Heat traceability numbers referenced: <span className="font-mono text-white font-semibold">{activeMemo.heat_nos.join(', ')}</span></p>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500 text-center py-20">Choose an active dispatch memo to review or print certificates.</p>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: TRACEABILITY TIMELINE TREE */}
      {activeTab === 'traceability' && (
        <div className="space-y-6">
          <form onSubmit={handleTraceSearch} className="glass-card flex gap-3 max-w-xl">
            <div className="flex-grow relative">
              <Search className="w-5 h-5 absolute left-3 top-2.5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Enter Casting ID (e.g. CAST-26-00001) or Heat No..." 
                className="form-control pl-10"
                value={searchQuery}
                onChange={e=>setSearchQuery(e.target.value)}
              />
            </div>
            <button type="submit" className="btn btn-primary px-6">Search Trace</button>
          </form>

          {traceError && (
            <div className="p-3 text-xs bg-red-950/40 border border-red-500/20 text-red-200 rounded-lg max-w-xl">
              {traceError}
            </div>
          )}

          {traceResult && (
            <div className="glass-card fade-in space-y-6">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h3 className="font-bold text-white text-lg">Traceability Tree Map</h3>
                <span className="badge badge-info">{traceResult.type} Search Result</span>
              </div>

              {/* casting lineage visual chart layout */}
              {traceResult.type === 'Casting' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Visual tree ancestry diagram */}
                  <div className="space-y-6 relative pl-6 border-l-2 border-slate-800">
                    
                    {/* Item 1: Customer PO */}
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-slate-900 border-2 border-slate-500 flex items-center justify-center">
                        <GitCommit className="w-3 h-3 text-slate-400" />
                      </div>
                      <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg max-w-md">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">Customer Purchase Order</span>
                        <h4 className="font-bold text-white text-sm mt-0.5">{traceResult.ancestry.purchase_order?.customer_name || "Tata Motors"}</h4>
                        <div className="text-[10px] text-slate-400 mt-1">PO No: <span className="font-mono text-orange-400 font-bold">{traceResult.ancestry.purchase_order?.po_number || "PO-998"}</span> (Date: {traceResult.ancestry.purchase_order?.date || "2026-05-20"})</div>
                      </div>
                    </div>

                    {/* Item 2: Work Order */}
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-slate-900 border-2 border-slate-500 flex items-center justify-center">
                        <GitCommit className="w-3 h-3 text-slate-400" />
                      </div>
                      <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg max-w-md">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">Internal Work Order</span>
                        <h4 className="font-bold text-xs text-slate-200 mt-0.5">{traceResult.item.product_name}</h4>
                        <p className="text-[10px] text-slate-400 mt-1">WO Ref: <span className="font-mono text-orange-400 font-semibold">{traceResult.ancestry.work_order?.id || "WO-001"}</span> (Lot Size: {traceResult.ancestry.work_order?.quantity || 100})</p>
                      </div>
                    </div>

                    {/* Item 3: Plan */}
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-slate-900 border-2 border-slate-500 flex items-center justify-center">
                        <GitCommit className="w-3 h-3 text-slate-400" />
                      </div>
                      <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg max-w-md">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">Moulding & Core Planning</span>
                        <div className="text-[10px] text-slate-400 mt-1">Plan ID: <span className="font-mono">{traceResult.ancestry.plan?.id || "PLN-001"}</span> (Mould Line: {traceResult.ancestry.plan?.moulding_line})</div>
                      </div>
                    </div>

                    {/* Item 4: Melting Heat */}
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-slate-900 border-2 border-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/20">
                        <Flame className="w-3 h-3 text-orange-500 animate-pulse" />
                      </div>
                      <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-lg max-w-md">
                        <span className="text-[9px] font-bold text-orange-400 uppercase">Furnace Melt Pouring Heat No</span>
                        <h4 className="font-bold text-white text-sm mt-0.5">{traceResult.ancestry.heat?.id || "HEAT-26001"}</h4>
                        <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
                          <div>Grade: <span className="text-white">{traceResult.ancestry.heat?.grade_name}</span></div>
                          <div>Chemistry: <span className="text-emerald-400 font-bold">Passed</span></div>
                          <div>Mechanical: <span className="text-emerald-400 font-bold">Passed</span></div>
                        </div>
                      </div>
                    </div>

                    {/* Item 5: Casting Serial */}
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-orange-500 border-2 border-white flex items-center justify-center">
                        <GitCommit className="w-3 h-3 text-white" />
                      </div>
                      <div className="p-3 bg-orange-500/10 border border-orange-500/40 rounded-lg max-w-md">
                        <span className="text-[9px] font-bold text-orange-400 uppercase">Current Casting Target</span>
                        <h4 className="font-bold text-white text-sm mt-0.5">{traceResult.item.id}</h4>
                        <div className="grid grid-cols-2 gap-2 mt-1 text-[10px] text-slate-400">
                          <div>Poured: <span className="text-white">{traceResult.item.date_moulded}</span></div>
                          <div>Shift: <span className="text-white">{traceResult.item.shift}</span></div>
                          <div>Operator: <span className="text-white">{traceResult.item.worker_details}</span></div>
                          <div>Stage: <span className="text-orange-400 font-bold">{traceResult.item.stage}</span></div>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Chemistry/materials detail column */}
                  <div className="space-y-4">
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                      <h4 className="font-bold text-xs text-orange-400 uppercase tracking-wider mb-3">Loaded Scrap & Alloys Recipe:</h4>
                      <div className="space-y-2 text-xs">
                        {traceResult.ancestry.raw_materials.map((m, idx) => (
                          <div key={idx} className="flex justify-between p-2 rounded bg-slate-950">
                            <span>Material ID: {m.material_id === 'INV001' ? 'Pig Iron' : m.material_id === 'INV002' ? 'Steel Scrap' : 'Ferro-Silicon'}</span>
                            <span className="font-bold text-white">{m.qty_kg} kg</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                      <h4 className="font-bold text-xs text-orange-400 uppercase tracking-wider mb-3">Registered Chemistry Values:</h4>
                      <div className="grid grid-cols-5 gap-2 text-center">
                        {Object.entries(traceResult.ancestry.chemical_test.chemistry_readings).map(([el, val]) => (
                          <div key={el} className="p-2 bg-slate-950 rounded">
                            <span className="text-[9px] text-slate-500 font-bold block">{el}</span>
                            <span className="font-mono text-white text-xs font-semibold">{val}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}
        </div>
      )}
    </div>
  );
}

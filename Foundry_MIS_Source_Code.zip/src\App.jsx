import React, { useState, useEffect } from 'react';
import { 
  Flame, LayoutDashboard, Database, ReceiptIndianRupee, 
  Settings, ShieldAlert, LogOut, CheckCircle, HelpCircle, ShieldCheck
} from 'lucide-react';
import Dashboard from './components/Dashboard.jsx';
import Masters from './components/Masters.jsx';
import SalesOrder from './components/SalesOrder.jsx';
import Production from './components/Production.jsx';
import Quality from './components/Quality.jsx';
import DispatchTraceability from './components/DispatchTraceability.jsx';

// --- CLIENT CUSTOMIZATION CONFIGURATION ---
// Change these values to customize the application for your client
export const CLIENT_CONFIG = {
  name: "CastTrace Pro",
  subtitle: "Foundry Management Information System",
  // To use a custom logo image, place it in the public folder and provide the filename below (e.g., '/logo.png')
  // If left empty (''), the default Flame icon will be used.
  logoUrl: "" 
};

export default function App() {
  const [user, setUser] = useState(null);
  const [usernameInput, setUsernameInput] = useState('admin');
  const [passwordInput, setPasswordInput] = useState('123');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [toasts, setToasts] = useState([]);

  // Auto-clear toasts after 5 seconds
  useEffect(() => {
    if (toasts.length > 0) {
      const timer = setTimeout(() => {
        setToasts(prev => prev.slice(1));
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toasts]);

  const addToast = (message, type = 'error') => {
    setToasts(prev => [...prev, { id: Date.now(), message, type }]);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: usernameInput, password: passwordInput })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setUser(data.user);
        setActiveTab('dashboard');
      } else {
        setLoginError(data.message || 'Login failed');
      }
    } catch (err) {
      // Mock Login fail-safe if server is not running yet
      console.warn("Server connection failed, using offline mock auth fallback");
      if (usernameInput === 'admin' && passwordInput === '123') {
        setUser({ id: 'U001', username: 'admin', role: 'Admin', name: 'System Administrator' });
      } else if (usernameInput === 'sales' && passwordInput === '123') {
        setUser({ id: 'U002', username: 'sales', role: 'Sales', name: 'Sales Head' });
      } else if (usernameInput === 'prod' && passwordInput === '123') {
        setUser({ id: 'U003', username: 'prod', role: 'Production', name: 'Production Manager' });
      } else if (usernameInput === 'quality' && passwordInput === '123') {
        setUser({ id: 'U004', username: 'quality', role: 'Quality', name: 'QC Lead' });
      } else if (usernameInput === 'dispatch' && passwordInput === '123') {
        setUser({ id: 'U005', username: 'dispatch', role: 'Dispatch', name: 'Dispatch In-charge' });
      } else {
        setLoginError('Invalid username or password (offline backup)');
      }
    }
  };

  const handleLogout = () => {
    setUser(null);
    setUsernameInput('');
    setPasswordInput('');
  };

  // Check roles permissions
  const hasAccess = (tab) => {
    if (!user) return false;
    if (user.role === 'Admin') return true;
    switch(tab) {
      case 'dashboard': return true;
      case 'masters': return false; // Admin only
      case 'sales': return user.role === 'Sales';
      case 'production': return user.role === 'Production';
      case 'quality': return user.role === 'Quality';
      case 'dispatch': return user.role === 'Dispatch' || user.role === 'Quality';
      default: return false;
    }
  };

  if (!user) {
    return (
      <div className="login-screen">
        <div className="login-glow"></div>
        
        <form onSubmit={handleLogin} className="login-form-card glass-card glow-border fade-in">
          <div className="login-header">
            {CLIENT_CONFIG.logoUrl ? (
              <img src={CLIENT_CONFIG.logoUrl} alt="Logo" style={{ width: '4rem', height: '4rem', marginBottom: '1rem', objectFit: 'contain' }} />
            ) : (
              <Flame className="brand-icon" style={{ width: '3.5rem', height: '3.5rem', marginBottom: '1rem' }} />
            )}
            <h1 className="login-header-title">{CLIENT_CONFIG.name}</h1>
            <p className="login-header-subtitle">{CLIENT_CONFIG.subtitle}</p>
          </div>

          {loginError && (
            <div className="p-3 mb-4 text-sm rounded bg-red-950/50 border border-red-500/30 text-red-200">
              {loginError}
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Username</label>
            <input 
              type="text" 
              className="form-control" 
              value={usernameInput} 
              onChange={e => setUsernameInput(e.target.value)} 
              required 
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input 
              type="password" 
              className="form-control" 
              value={passwordInput} 
              onChange={e => setPasswordInput(e.target.value)} 
              required 
            />
          </div>

          <button type="submit" className="w-full mt-4 btn btn-primary">
            Sign In to Core MIS
          </button>

        </form>
      </div>
    );
  }

  return (
    <div className="app-container">
      {/* Toast Notification Container */}
      <div className="toast-container">
        {toasts.map(toast => (
          <div key={toast.id} className="interlock-banner fade-in">
            <ShieldAlert className="w-6 h-6 flex-shrink-0 text-white mt-0.5" />
            <div>
              <h4 className="font-bold text-sm text-white">INTERLOCK PREVENTED</h4>
              <p className="text-xs text-red-100 mt-1">{toast.message}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div className="brand-title">
          {CLIENT_CONFIG.logoUrl ? (
            <img src={CLIENT_CONFIG.logoUrl} alt="Logo" className="w-8 h-8 object-contain" />
          ) : (
            <Flame className="w-8 h-8 brand-icon" />
          )}
          <span className="gradient-text truncate" title={CLIENT_CONFIG.name}>{CLIENT_CONFIG.name}</span>
        </div>

        <nav style={{ flexGrow: 1 }}>
          <ul className="nav-menu">
            <li>
              <div 
                className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
                onClick={() => setActiveTab('dashboard')}
              >
                <LayoutDashboard className="w-5 h-5" />
                <span>Dashboard</span>
              </div>
            </li>
            {hasAccess('masters') && (
              <li>
                <div 
                  className={`nav-item ${activeTab === 'masters' ? 'active' : ''}`}
                  onClick={() => setActiveTab('masters')}
                >
                  <Database className="w-5 h-5" />
                  <span>Master Data</span>
                </div>
              </li>
            )}
            {(hasAccess('sales') || user.role === 'Admin') && (
              <li>
                <div 
                  className={`nav-item ${activeTab === 'sales' ? 'active' : ''}`}
                  onClick={() => setActiveTab('sales')}
                >
                  <ReceiptIndianRupee className="w-5 h-5" />
                  <span>Sales & Orders</span>
                </div>
              </li>
            )}
            {(hasAccess('production') || user.role === 'Admin') && (
              <li>
                <div 
                  className={`nav-item ${activeTab === 'production' ? 'active' : ''}`}
                  onClick={() => setActiveTab('production')}
                >
                  <Flame className="w-5 h-5 text-orange-400" />
                  <span>Production Execution</span>
                </div>
              </li>
            )}
            {(hasAccess('quality') || user.role === 'Admin') && (
              <li>
                <div 
                  className={`nav-item ${activeTab === 'quality' ? 'active' : ''}`}
                  onClick={() => setActiveTab('quality')}
                >
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>Quality Control</span>
                </div>
              </li>
            )}
            {(hasAccess('dispatch') || user.role === 'Admin') && (
              <li>
                <div 
                  className={`nav-item ${activeTab === 'dispatch' ? 'active' : ''}`}
                  onClick={() => setActiveTab('dispatch')}
                >
                  <CheckCircle className="w-5 h-5 text-cyan-400" />
                  <span>Dispatch & Trace</span>
                </div>
              </li>
            )}
          </ul>
        </nav>

        {/* User Info & Logout */}
        <div className="pt-4 mt-auto border-t border-slate-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-orange-500">
              {user.role.substring(0,2).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <h5 className="font-semibold text-sm truncate text-white">{user.name}</h5>
              <span className="text-[11px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded font-mono uppercase">{user.role}</span>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full btn btn-secondary flex items-center justify-center gap-2">
            <LogOut className="w-4 h-4 text-slate-400" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Panel */}
      <main className="main-content">
        {/* Process Flow Header Tracker */}
        <div className="mb-6 overflow-x-auto pb-2">
          <div className="flow-diagram">
            <span className="text-[10px] text-slate-500 font-mono uppercase mr-2">Core Interlocks:</span>
            <div className={`flow-step ${['masters'].includes(activeTab) ? 'active' : ''} ${activeTab !== 'masters' ? 'completed' : ''}`}>Customer Master</div>
            <span className="flow-arrow">→</span>
            <div className={`flow-step ${['sales'].includes(activeTab) ? 'active' : ''} ${!['masters', 'sales'].includes(activeTab) ? 'completed' : ''}`}>Enquiry / Quotation / PO</div>
            <span className="flow-arrow">→</span>
            <div className={`flow-step ${['production'].includes(activeTab) ? 'active' : ''} ${['quality', 'dispatch'].includes(activeTab) ? 'completed' : ''}`}>Pre-Pour Chemistry OK</div>
            <span className="flow-arrow">→</span>
            <div className={`flow-step ${['production'].includes(activeTab) ? 'active' : ''} ${['quality', 'dispatch'].includes(activeTab) ? 'completed' : ''}`}>Melting Heat Log</div>
            <span className="flow-arrow">→</span>
            <div className={`flow-step ${['quality'].includes(activeTab) ? 'active' : ''} ${activeTab === 'dispatch' ? 'completed' : ''}`}>Knockout & Mechanical Test OK</div>
            <span className="flow-arrow">→</span>
            <div className={`flow-step ${['quality'].includes(activeTab) ? 'active' : ''} ${activeTab === 'dispatch' ? 'completed' : ''}`}>Fettling & Painting Approval</div>
            <span className="flow-arrow">→</span>
            <div className={`flow-step ${activeTab === 'dispatch' ? 'active' : ''}`}>Dispatch Clearance Memo</div>
          </div>
        </div>

        {/* Dynamic Tab Renderer */}
        <div className="fade-in">
          {activeTab === 'dashboard' && <Dashboard addToast={addToast} />}
          {activeTab === 'masters' && <Masters addToast={addToast} />}
          {activeTab === 'sales' && <SalesOrder addToast={addToast} />}
          {activeTab === 'production' && <Production addToast={addToast} />}
          {activeTab === 'quality' && <Quality addToast={addToast} />}
          {activeTab === 'dispatch' && <DispatchTraceability addToast={addToast} />}
        </div>
      </main>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Edit3, Shield, Info, ArrowUpRight, Scale, Users, Truck, FileBadge, Package, Box, UserCog, Ruler } from 'lucide-react';

const tabsConfig = [
  { id: 'customers', label: 'Customers', icon: Users, desc: 'Client profiles' },
  { id: 'suppliers', label: 'Suppliers', icon: Truck, desc: 'Vendor records' },
  { id: 'grades', label: 'Grades', icon: FileBadge, desc: 'Material specs' },
  { id: 'products', label: 'Products', icon: Package, desc: 'Casting registry' },
  { id: 'inventory', label: 'Inventory', icon: Box, desc: 'Stock levels' },
  { id: 'users', label: 'Users', icon: UserCog, desc: 'System access' },
  { id: 'units', label: 'Units', icon: Ruler, desc: 'Measurements' },
];

export default function Masters({ addToast }) {
  const [activeSubTab, setActiveSubTab] = useState('customers');
  const [dataList, setDataList] = useState([]);
  const [gradesList, setGradesList] = useState([]); // Cached for product dropdown
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState(null);

  // Form states
  const [customerForm, setCustomerForm] = useState({ name: '', contact: '', address: '', email: '' });
  const [supplierForm, setSupplierForm] = useState({ name: '', contact: '', address: '', email: '' });
  const [unitForm, setUnitForm] = useState({ code: '', name: '' });
  const [inventoryForm, setInventoryForm] = useState({ name: '', stock: 0, min_stock: 0, unit: 'kg' });
  const [userForm, setUserForm] = useState({ username: '', password: '', role: 'Production', full_name: '' });
  
  const [gradeForm, setGradeForm] = useState({
    name: '',
    C_min: 3.10, C_max: 3.40,
    Si_min: 1.80, Si_max: 2.10,
    Mn_min: 0.60, Mn_max: 0.90,
    S_min: 0.00, S_max: 0.12,
    P_min: 0.00, P_max: 0.15,
    Mg_min: 0.00, Mg_max: 0.00, // For SG iron
    tensile_min: 260,
    hardness_min: 180,
    hardness_max: 230,
    elongation_min: 0
  });

  const [productForm, setProductForm] = useState({
    code: '',
    name: '',
    drawing_no: '',
    grade_id: '',
    net_weight: 0.0,
    gross_weight: 0.0,
    customer_id: '',
    unit_id: 'U_NOS'
  });

  const [customersDropdown, setCustomersDropdown] = useState([]);
  const [unitsDropdown, setUnitsDropdown] = useState([]);

  useEffect(() => {
    fetchData();
  }, [activeSubTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/masters/${activeSubTab}`);
      if (res.ok) {
        const data = await res.json();
        setDataList(data);
      }
      
      // Load dependencies
      if (activeSubTab === 'products') {
        const resGrades = await fetch('/api/masters/grades');
        const resCusts = await fetch('/api/masters/customers');
        const resUnits = await fetch('/api/masters/units');
        if (resGrades.ok) setGradesList(await resGrades.json());
        if (resCusts.ok) setCustomersDropdown(await resCusts.json());
        if (resUnits.ok) setUnitsDropdown(await resUnits.json());
      }
      setLoading(false);
    } catch (err) {
      console.warn("Offline fallback for masters data");
      setLoading(false);
    }
  };

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    let body = {};
    
    if (activeSubTab === 'customers') body = customerForm;
    else if (activeSubTab === 'suppliers') body = supplierForm;
    else if (activeSubTab === 'units') body = unitForm;
    else if (activeSubTab === 'inventory') body = inventoryForm;
    else if (activeSubTab === 'users') body = userForm;
    else if (activeSubTab === 'grades') {
      // Reformat chemical/mechanical structure for server schema
      body = {
        name: gradeForm.name,
        chemical: {
          C: { min: Number(gradeForm.C_min), max: Number(gradeForm.C_max) },
          Si: { min: Number(gradeForm.Si_min), max: Number(gradeForm.Si_max) },
          Mn: { min: Number(gradeForm.Mn_min), max: Number(gradeForm.Mn_max) },
          S: { min: Number(gradeForm.S_min), max: Number(gradeForm.S_max) },
          P: { min: Number(gradeForm.P_min), max: Number(gradeForm.P_max) }
        },
        mechanical: {
          tensile_min: Number(gradeForm.tensile_min),
          hardness_min: Number(gradeForm.hardness_min),
          hardness_max: Number(gradeForm.hardness_max),
          elongation_min: Number(gradeForm.elongation_min)
        }
      };
      if (Number(gradeForm.Mg_max) > 0) {
        body.chemical.Mg = { min: Number(gradeForm.Mg_min), max: Number(gradeForm.Mg_max) };
      }
    } 
    else if (activeSubTab === 'products') {
      body = {
        ...productForm,
        net_weight: Number(productForm.net_weight),
        gross_weight: Number(productForm.gross_weight)
      };
    }

    try {
      const url = editingId ? `/api/masters/${activeSubTab}/${editingId}` : `/api/masters/${activeSubTab}`;
      const method = editingId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      
      const data = await res.json();
      if (res.ok) {
        setShowAddForm(false);
        setEditingId(null);
        fetchData();
        // Reset forms
        setCustomerForm({ name: '', contact: '', address: '', email: '' });
        setSupplierForm({ name: '', contact: '', address: '', email: '' });
        setUnitForm({ code: '', name: '' });
        setInventoryForm({ name: '', stock: 0, min_stock: 0, unit: 'kg' });
        setUserForm({ username: '', password: '', role: 'Production', full_name: '' });
        setProductForm({ code: '', name: '', drawing_no: '', grade_id: '', net_weight: 0, gross_weight: 0, customer_id: '', unit_id: 'U_NOS' });
        setGradeForm({ name: '', C_min: 3.10, C_max: 3.40, Si_min: 1.80, Si_max: 2.10, Mn_min: 0.60, Mn_max: 0.90, S_min: 0.00, S_max: 0.12, P_min: 0.00, P_max: 0.15, Mg_min: 0.00, Mg_max: 0.00, tensile_min: 260, hardness_min: 180, hardness_max: 230, elongation_min: 0 });
      } else {
        addToast(data.message || "Failed to save record.");
      }
    } catch (err) {
      addToast("Failed to connect to backend server. Run server locally.", "error");
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this master item?")) return;
    try {
      const res = await fetch(`/api/masters/${activeSubTab}/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchData();
      } else {
        const data = await res.json();
        addToast(data.message || "Cannot delete item. It is referenced in active orders.");
      }
    } catch (err) {
      addToast("Failed to connect to server.", "error");
    }
  };

  const handleEdit = (item) => {
    setEditingId(item.id);
    if (activeSubTab === 'customers') {
      setCustomerForm({ name: item.name, contact: item.contact, address: item.address, email: item.email });
    } else if (activeSubTab === 'suppliers') {
      setSupplierForm({ name: item.name, contact: item.contact, address: item.address, email: item.email });
    } else if (activeSubTab === 'units') {
      setUnitForm({ code: item.code, name: item.name });
    } else if (activeSubTab === 'inventory') {
      setInventoryForm({ name: item.name, stock: item.stock, min_stock: item.min_stock, unit: item.unit });
    } else if (activeSubTab === 'users') {
      setUserForm({ username: item.username, password: item.password, role: item.role, full_name: item.full_name });
    } else if (activeSubTab === 'grades') {
      setGradeForm({
        name: item.name,
        C_min: item.chemical?.C?.min || 0, C_max: item.chemical?.C?.max || 0,
        Si_min: item.chemical?.Si?.min || 0, Si_max: item.chemical?.Si?.max || 0,
        Mn_min: item.chemical?.Mn?.min || 0, Mn_max: item.chemical?.Mn?.max || 0,
        S_min: item.chemical?.S?.min || 0, S_max: item.chemical?.S?.max || 0,
        P_min: item.chemical?.P?.min || 0, P_max: item.chemical?.P?.max || 0,
        Mg_min: item.chemical?.Mg?.min || 0, Mg_max: item.chemical?.Mg?.max || 0,
        tensile_min: item.mechanical?.tensile_min || 0,
        hardness_min: item.mechanical?.hardness_min || 0,
        hardness_max: item.mechanical?.hardness_max || 0,
        elongation_min: item.mechanical?.elongation_min || 0
      });
    } else if (activeSubTab === 'products') {
      setProductForm({
        code: item.code, name: item.name, drawing_no: item.drawing_no,
        grade_id: item.grade_id, net_weight: item.net_weight,
        gross_weight: item.gross_weight, customer_id: item.customer_id,
        unit_id: item.unit_id
      });
    }
    setShowAddForm(true);
  };

  const handleToggleForm = () => {
    if (showAddForm) {
      setShowAddForm(false);
      setEditingId(null);
      // Reset forms
      setCustomerForm({ name: '', contact: '', address: '', email: '' });
      setSupplierForm({ name: '', contact: '', address: '', email: '' });
      setUnitForm({ code: '', name: '' });
      setInventoryForm({ name: '', stock: 0, min_stock: 0, unit: 'kg' });
      setUserForm({ username: '', password: '', role: 'Production', full_name: '' });
      setProductForm({ code: '', name: '', drawing_no: '', grade_id: '', net_weight: 0, gross_weight: 0, customer_id: '', unit_id: 'U_NOS' });
      setGradeForm({ name: '', C_min: 3.10, C_max: 3.40, Si_min: 1.80, Si_max: 2.10, Mn_min: 0.60, Mn_max: 0.90, S_min: 0.00, S_max: 0.12, P_min: 0.00, P_max: 0.15, Mg_min: 0.00, Mg_max: 0.00, tensile_min: 260, hardness_min: 180, hardness_max: 230, elongation_min: 0 });
    } else {
      setShowAddForm(true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold text-white">Master Configuration</h1>
          <p className="text-slate-400 text-sm mt-1">Foundational data registries. Must map before recording castings or orders.</p>
        </div>
        <button 
          onClick={handleToggleForm} 
          className="btn btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>{showAddForm ? "View Directory" : "Add New Record"}</span>
        </button>
      </div>

      {/* Sub tabs navigation - Professional Grid */}
      <div className="master-nav-grid">
        {tabsConfig.map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                if (activeSubTab !== tab.id) {
                  setDataList([]); // Clear old data to prevent render crashes
                  setActiveSubTab(tab.id);
                  setShowAddForm(false);
                  setEditingId(null);
                }
              }}
              className={`master-btn ${isActive ? 'active' : ''}`}
            >
              <div className="master-btn-glow"></div>
              <div className="master-btn-icon-wrapper">
                <Icon size={26} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className="master-btn-label">{tab.label}</span>
              <span className="master-btn-desc">{tab.desc}</span>
            </button>
          );
        })}
      </div>

      {showAddForm ? (
        /* Dynamic forms wrapper */
        <div className="glass-card fade-in">
          <h2 className="text-lg font-bold text-white mb-4 uppercase tracking-wider">
            {editingId ? "Update" : "Create New"} {activeSubTab.slice(0, -1)}
          </h2>
          <form onSubmit={handleAddSubmit} className="space-y-4">
            
            {/* 1. CUSTOMERS FORM */}
            {activeSubTab === 'customers' && (
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Company Name</label>
                  <input type="text" className="form-control" required value={customerForm.name} onChange={e=>setCustomerForm({...customerForm, name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Phone Contact</label>
                  <input type="text" className="form-control" required value={customerForm.contact} onChange={e=>setCustomerForm({...customerForm, contact: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Email Address</label>
                  <input type="email" className="form-control" required value={customerForm.email} onChange={e=>setCustomerForm({...customerForm, email: e.target.value})} />
                </div>
                <div className="form-group col-span-2">
                  <label className="form-label">Delivery Address</label>
                  <input type="text" className="form-control" required value={customerForm.address} onChange={e=>setCustomerForm({...customerForm, address: e.target.value})} />
                </div>
              </div>
            )}

            {/* 2. SUPPLIERS FORM */}
            {activeSubTab === 'suppliers' && (
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Supplier Name</label>
                  <input type="text" className="form-control" required value={supplierForm.name} onChange={e=>setSupplierForm({...supplierForm, name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Contact Number</label>
                  <input type="text" className="form-control" required value={supplierForm.contact} onChange={e=>setSupplierForm({...supplierForm, contact: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <input type="email" className="form-control" required value={supplierForm.email} onChange={e=>setSupplierForm({...supplierForm, email: e.target.value})} />
                </div>
                <div className="form-group col-span-2">
                  <label className="form-label">Billing Address</label>
                  <input type="text" className="form-control" required value={supplierForm.address} onChange={e=>setSupplierForm({...supplierForm, address: e.target.value})} />
                </div>
              </div>
            )}

            {/* 3. UNITS FORM */}
            {activeSubTab === 'units' && (
              <div className="form-grid max-w-lg">
                <div className="form-group">
                  <label className="form-label">Unit Code (e.g. kg, nos)</label>
                  <input type="text" className="form-control" placeholder="kg" required value={unitForm.code} onChange={e=>setUnitForm({...unitForm, code: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Unit Name</label>
                  <input type="text" className="form-control" placeholder="Kilogram" required value={unitForm.name} onChange={e=>setUnitForm({...unitForm, name: e.target.value})} />
                </div>
              </div>
            )}

            {/* 4. INVENTORY FORM */}
            {activeSubTab === 'inventory' && (
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Material Name</label>
                  <input type="text" className="form-control" placeholder="Ferro-Silicon" required value={inventoryForm.name} onChange={e=>setInventoryForm({...inventoryForm, name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Current Stock Level</label>
                  <input type="number" className="form-control" required value={inventoryForm.stock} onChange={e=>setInventoryForm({...inventoryForm, stock: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Minimum Safety stock limit</label>
                  <input type="number" className="form-control" required value={inventoryForm.min_stock} onChange={e=>setInventoryForm({...inventoryForm, min_stock: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Stock Unit</label>
                  <select className="form-control" value={inventoryForm.unit} onChange={e=>setInventoryForm({...inventoryForm, unit: e.target.value})}>
                    <option value="kg">kg</option>
                    <option value="ton">ton</option>
                    <option value="nos">nos</option>
                  </select>
                </div>
              </div>
            )}

            {/* 5. USERS FORM */}
            {activeSubTab === 'users' && (
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">User Full Name</label>
                  <input type="text" className="form-control" required value={userForm.full_name} onChange={e=>setUserForm({...userForm, full_name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Username (Sign In ID)</label>
                  <input type="text" className="form-control" required value={userForm.username} onChange={e=>setUserForm({...userForm, username: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Password</label>
                  <input type="password" className="form-control" required value={userForm.password} onChange={e=>setUserForm({...userForm, password: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">System Role Access</label>
                  <select className="form-control" value={userForm.role} onChange={e=>setUserForm({...userForm, role: e.target.value})}>
                    <option value="Admin">Admin</option>
                    <option value="Sales">Sales</option>
                    <option value="Production">Production</option>
                    <option value="Quality">Quality</option>
                    <option value="Dispatch">Dispatch</option>
                  </select>
                </div>
              </div>
            )}

            {/* 6. GRADE MASTER SPEC RANGE BUILDER */}
            {activeSubTab === 'grades' && (
              <div className="space-y-4">
                <div className="form-group max-w-md">
                  <label className="form-label">Grade Name / Standard</label>
                  <input type="text" className="form-control" placeholder="SG400/15 (Ductile Iron)" required value={gradeForm.name} onChange={e=>setGradeForm({...gradeForm, name: e.target.value})} />
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <h3 className="font-bold text-xs text-orange-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Info className="w-4 h-4" /> Chemical Target Specs (Range limits %)
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Carbon (C) %</label>
                      <div className="flex gap-1 mt-1">
                        <input type="number" step="0.01" className="form-control py-1 px-2 text-xs" placeholder="Min" value={gradeForm.C_min} onChange={e=>setGradeForm({...gradeForm, C_min: e.target.value})} />
                        <input type="number" step="0.01" className="form-control py-1 px-2 text-xs" placeholder="Max" value={gradeForm.C_max} onChange={e=>setGradeForm({...gradeForm, C_max: e.target.value})} />
                      </div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Silicon (Si) %</label>
                      <div className="flex gap-1 mt-1">
                        <input type="number" step="0.01" className="form-control py-1 px-2 text-xs" placeholder="Min" value={gradeForm.Si_min} onChange={e=>setGradeForm({...gradeForm, Si_min: e.target.value})} />
                        <input type="number" step="0.01" className="form-control py-1 px-2 text-xs" placeholder="Max" value={gradeForm.Si_max} onChange={e=>setGradeForm({...gradeForm, Si_max: e.target.value})} />
                      </div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Manganese (Mn) %</label>
                      <div className="flex gap-1 mt-1">
                        <input type="number" step="0.01" className="form-control py-1 px-2 text-xs" placeholder="Min" value={gradeForm.Mn_min} onChange={e=>setGradeForm({...gradeForm, Mn_min: e.target.value})} />
                        <input type="number" step="0.01" className="form-control py-1 px-2 text-xs" placeholder="Max" value={gradeForm.Mn_max} onChange={e=>setGradeForm({...gradeForm, Mn_max: e.target.value})} />
                      </div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Sulfur (S) %</label>
                      <div className="flex gap-1 mt-1">
                        <input type="number" step="0.001" className="form-control py-1 px-2 text-xs" placeholder="Min" value={gradeForm.S_min} onChange={e=>setGradeForm({...gradeForm, S_min: e.target.value})} />
                        <input type="number" step="0.001" className="form-control py-1 px-2 text-xs" placeholder="Max" value={gradeForm.S_max} onChange={e=>setGradeForm({...gradeForm, S_max: e.target.value})} />
                      </div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Phosphorus (P) %</label>
                      <div className="flex gap-1 mt-1">
                        <input type="number" step="0.001" className="form-control py-1 px-2 text-xs" placeholder="Min" value={gradeForm.P_min} onChange={e=>setGradeForm({...gradeForm, P_min: e.target.value})} />
                        <input type="number" step="0.001" className="form-control py-1 px-2 text-xs" placeholder="Max" value={gradeForm.P_max} onChange={e=>setGradeForm({...gradeForm, P_max: e.target.value})} />
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 max-w-xs p-2 bg-slate-950 rounded border border-slate-800">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Magnesium (Mg) % (Spheroidal)</label>
                    <div className="flex gap-1 mt-1">
                      <input type="number" step="0.001" className="form-control py-1 px-2 text-xs" placeholder="Min" value={gradeForm.Mg_min} onChange={e=>setGradeForm({...gradeForm, Mg_min: e.target.value})} />
                      <input type="number" step="0.001" className="form-control py-1 px-2 text-xs" placeholder="Max" value={gradeForm.Mg_max} onChange={e=>setGradeForm({...gradeForm, Mg_max: e.target.value})} />
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <h3 className="font-bold text-xs text-orange-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Scale className="w-4 h-4" /> Mechanical Spec Minimums
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="form-group">
                      <label className="form-label">Tensile Strength (Min MPa)</label>
                      <input type="number" className="form-control" value={gradeForm.tensile_min} onChange={e=>setGradeForm({...gradeForm, tensile_min: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Hardness (Min BHN)</label>
                      <input type="number" className="form-control" value={gradeForm.hardness_min} onChange={e=>setGradeForm({...gradeForm, hardness_min: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Hardness (Max BHN)</label>
                      <input type="number" className="form-control" value={gradeForm.hardness_max} onChange={e=>setGradeForm({...gradeForm, hardness_max: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Elongation (Min %)</label>
                      <input type="number" className="form-control" value={gradeForm.elongation_min} onChange={e=>setGradeForm({...gradeForm, elongation_min: e.target.value})} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 7. PRODUCTS FORM WITH MAP */}
            {activeSubTab === 'products' && (
              <div className="space-y-4">
                <div className="form-grid">
                  <div className="form-group">
                    <label className="form-label">Product Short Code</label>
                    <input type="text" className="form-control" placeholder="FW-HOUSING-TATA" required value={productForm.code} onChange={e=>setProductForm({...productForm, code: e.target.value})} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Product Description Name</label>
                    <input type="text" className="form-control" placeholder="Tata Flywheel Housing" required value={productForm.name} onChange={e=>setProductForm({...productForm, name: e.target.value})} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Drawing Reference No</label>
                    <input type="text" className="form-control" placeholder="TATA-FW-102-REV3" required value={productForm.drawing_no} onChange={e=>setProductForm({...productForm, drawing_no: e.target.value})} />
                  </div>
                </div>

                <div className="form-grid">
                  <div className="form-group">
                    <label className="form-label">Design Grade standard mapping</label>
                    <select className="form-control" required value={productForm.grade_id} onChange={e=>setProductForm({...productForm, grade_id: e.target.value})}>
                      <option value="">-- Choose Grade specification --</option>
                      {gradesList.map(g => (
                        <option key={g.id} value={g.id}>{g.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Map Customer Owner</label>
                    <select className="form-control" required value={productForm.customer_id} onChange={e=>setProductForm({...productForm, customer_id: e.target.value})}>
                      <option value="">-- Choose Customer --</option>
                      {customersDropdown.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Net Casting Weight (kg)</label>
                    <input type="number" step="0.1" className="form-control" required value={productForm.net_weight} onChange={e=>setProductForm({...productForm, net_weight: e.target.value})} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Gross Pouring Weight (kg)</label>
                    <input type="number" step="0.1" className="form-control" required value={productForm.gross_weight} onChange={e=>setProductForm({...productForm, gross_weight: e.target.value})} />
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button type="submit" className="btn btn-primary">{editingId ? "Update Master" : "Save Master"}</button>
              <button type="button" onClick={handleToggleForm} className="btn btn-secondary">Cancel</button>
            </div>
          </form>
        </div>
      ) : (
        /* Directory listings grids */
        <div className="glass-card fade-in">
          {loading ? (
            <div className="text-center py-10 text-slate-500">Loading Directory registries...</div>
          ) : (
            <div className="table-container">
              <table className="custom-table">
                
                {/* 1. CUSTOMERS DIRECTORY */}
                {activeSubTab === 'customers' && (
                  <>
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Company Name</th>
                        <th>Contact Number</th>
                        <th>Email Address</th>
                        <th>Location Address</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white">{item.name}</td>
                          <td>{item.contact}</td>
                          <td>{item.email}</td>
                          <td className="text-slate-400 text-xs">{item.address}</td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {/* 2. SUPPLIERS DIRECTORY */}
                {activeSubTab === 'suppliers' && (
                  <>
                    <thead>
                      <tr>
                        <th>Supplier ID</th>
                        <th>Company Name</th>
                        <th>Phone</th>
                        <th>Email Address</th>
                        <th>Billing Address</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white">{item.name}</td>
                          <td>{item.contact}</td>
                          <td>{item.email}</td>
                          <td className="text-slate-400 text-xs">{item.address}</td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {/* 3. UNITS DIRECTORY */}
                {activeSubTab === 'units' && (
                  <>
                    <thead>
                      <tr>
                        <th>Unit ID</th>
                        <th>Symbol Code</th>
                        <th>Display Name</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white font-mono">{item.code}</td>
                          <td>{item.name}</td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {/* 4. INVENTORY DIRECTORY */}
                {activeSubTab === 'inventory' && (
                  <>
                    <thead>
                      <tr>
                        <th>Item ID</th>
                        <th>Raw Material</th>
                        <th>Available Stock</th>
                        <th>Safety stock limit</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white">{item.name}</td>
                          <td className="font-mono">{item.stock}</td>
                          <td className="font-mono text-slate-500">{item.min_stock}</td>
                          <td>{item.unit}</td>
                          <td>
                            {item.stock < item.min_stock ? (
                              <span className="badge badge-danger">Shortage Warning</span>
                            ) : (
                              <span className="badge badge-success">Stock OK</span>
                            )}
                          </td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {/* 5. USERS DIRECTORY */}
                {activeSubTab === 'users' && (
                  <>
                    <thead>
                      <tr>
                        <th>User ID</th>
                        <th>Full Name</th>
                        <th>Username Sign In ID</th>
                        <th>System Authorization Role</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white">{item.full_name}</td>
                          <td>{item.username}</td>
                          <td>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${item.role === 'Admin' ? 'bg-orange-500/10 border-orange-500/30 text-orange-400' : 'bg-slate-800 border-slate-700 text-slate-400'}`}>{item.role}</span>
                          </td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {/* 6. GRADES DIRECTORY */}
                {activeSubTab === 'grades' && (
                  <>
                    <thead>
                      <tr>
                        <th>Grade ID</th>
                        <th>Grade Standard</th>
                        <th>Chemical Spec ranges</th>
                        <th>Mechanical Specification Limits</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white">{item.name}</td>
                          <td className="text-xs space-y-1">
                            <div><span className="font-semibold text-orange-500">C:</span> {item.chemical?.C?.min}% - {item.chemical?.C?.max}%</div>
                            <div><span className="font-semibold text-orange-500">Si:</span> {item.chemical?.Si?.min}% - {item.chemical?.Si?.max}%</div>
                            <div><span className="font-semibold text-orange-500">Mn:</span> {item.chemical?.Mn?.min}% - {item.chemical?.Mn?.max}%</div>
                            {item.chemical?.Mg && <div><span className="font-semibold text-orange-500">Mg:</span> {item.chemical?.Mg?.min}% - {item.chemical?.Mg?.max}%</div>}
                          </td>
                          <td className="text-xs space-y-1 text-slate-400">
                            <div><span className="font-semibold">Tensile Strength:</span> min {item.mechanical?.tensile_min} MPa</div>
                            <div><span className="font-semibold">Hardness range:</span> {item.mechanical?.hardness_min} - {item.mechanical?.hardness_max} BHN</div>
                            <div><span className="font-semibold">Elongation:</span> min {item.mechanical?.elongation_min}%</div>
                          </td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

                {/* 7. PRODUCTS DIRECTORY */}
                {activeSubTab === 'products' && (
                  <>
                    <thead>
                      <tr>
                        <th>Product ID</th>
                        <th>Design Code</th>
                        <th>Description</th>
                        <th>Drawing No</th>
                        <th>Grade</th>
                        <th>Weights (Net / Gross)</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dataList.map(item => (
                        <tr key={item.id}>
                          <td className="font-mono text-xs">{item.id}</td>
                          <td className="font-bold text-white font-mono">{item.code}</td>
                          <td>{item.name}</td>
                          <td className="font-semibold font-mono text-xs text-orange-400">{item.drawing_no}</td>
                          <td>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 border border-slate-700 text-slate-400">{item.grade_id}</span>
                          </td>
                          <td className="text-xs">
                            <div>Net: <span className="font-semibold text-white">{item.net_weight} kg</span></div>
                            <div>Gross: <span className="font-semibold text-slate-400">{item.gross_weight} kg</span></div>
                          </td>
                          <td>
                            <div className="flex items-center gap-1">
                              <button onClick={()=>handleEdit(item)} className="p-1 hover:text-blue-500 transition-colors text-slate-500"><Edit3 className="w-4 h-4" /></button>
                              <button onClick={()=>handleDelete(item.id)} className="p-1 hover:text-red-500 transition-colors text-slate-500"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </>
                )}

              </table>
              {dataList.length === 0 && (
                <p className="text-slate-500 text-center py-8 text-xs">No records exist in database. Add new items to start.</p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { ShoppingBag, FileText, CheckCircle2, ChevronRight, Play, AlertCircle } from 'lucide-react';

export default function SalesOrder({ addToast }) {
  const [activeStep, setActiveStep] = useState('enquiry');
  
  // Lists
  const [enquiries, setEnquiries] = useState([]);
  const [quotations, setQuotations] = useState([]);
  const [pos, setPOs] = useState([]);
  const [wos, setWOs] = useState([]);
  
  // Dropdown cached masters
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);

  // Form states
  const [enqForm, setEnqForm] = useState({ customer_id: '', product_id: '', quantity: 100, target_date: '', is_new_dev: false });
  const [qtnForm, setQtnForm] = useState({ enquiry_id: '', costing: 'Raw materials + Machining cost', lead_time: 4, tech_specs: 'Surface finish Ra 3.2, sand blasted', rate: 120 });
  const [poForm, setPoForm] = useState({ po_number: '', quotation_id: '', rate: 120, qty: 100, date: '' });
  const [woForm, setWoForm] = useState({ po_id: '', delivery_date: '' });

  useEffect(() => {
    loadMasters();
    loadTransactions();
  }, [activeStep]);

  const loadMasters = async () => {
    try {
      const resCusts = await fetch('/api/masters/customers');
      const resProds = await fetch('/api/masters/products');
      if (resCusts.ok) setCustomers(await resCusts.json());
      if (resProds.ok) setProducts(await resProds.json());
    } catch (err) {
      console.warn("Offline fallback for sales master dependencies");
    }
  };

  const loadTransactions = async () => {
    try {
      const resEnq = await fetch('/api/masters/enquiries');
      const resQtn = await fetch('/api/masters/quotations');
      const resPO = await fetch('/api/masters/purchase_orders');
      const resWO = await fetch('/api/masters/work_orders');

      if (resEnq.ok) setEnquiries(await resEnq.json());
      if (resQtn.ok) setQuotations(await resQtn.json());
      if (resPO.ok) setPOs(await resPO.json());
      if (resWO.ok) setWOs(await resWO.json());
    } catch (err) {
      console.warn("Offline transaction lists load failed");
    }
  };

  // Step 1: Submit Enquiry
  const handleEnquirySubmit = async (e) => {
    e.preventDefault();
    if (!enqForm.customer_id) {
      addToast("Interlock Triggered: Customer Master record is required.", "error");
      return;
    }
    if (!enqForm.product_id) {
      addToast("Product code selection is required.", "error");
      return;
    }

    try {
      const res = await fetch('/api/sales/enquiry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: enqForm.customer_id,
          target_date: enqForm.target_date,
          items: [{ product_id: enqForm.product_id, qty: Number(enqForm.quantity), is_new_development: enqForm.is_new_dev }]
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Enquiry ${data.data.id} registered. Proceed to Quotation.`, "success");
        loadTransactions();
        setActiveStep('quotation');
      } else {
        addToast(data.message || "Failed to create Enquiry.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Enquiry entry.", "success");
      // Mock insert for offline fallback
      const mockId = `ENQ-26000${enquiries.length + 1}`;
      const customer = customers.find(c => c.id === enqForm.customer_id) || { name: 'Tata Motors' };
      const newEnq = {
        id: mockId,
        customer_id: enqForm.customer_id,
        customer_name: customer.name,
        target_date: enqForm.target_date,
        items: [{ product_id: enqForm.product_id, qty: Number(enqForm.quantity), is_new_development: enqForm.is_new_dev }],
        date: new Date().toISOString().split('T')[0],
        status: 'Pending Quotation'
      };
      setEnquiries(prev => [...prev, newEnq]);
      setActiveStep('quotation');
    }
  };

  // Step 2: Submit Quotation
  const handleQuotationSubmit = async (e) => {
    e.preventDefault();
    if (!qtnForm.enquiry_id) {
      addToast("Interlock Error: Quotation cannot be created without a reference Enquiry ID.", "error");
      return;
    }

    try {
      const res = await fetch('/api/sales/quotation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enquiry_id: qtnForm.enquiry_id,
          costing_details: qtnForm.costing,
          lead_time_weeks: Number(qtnForm.lead_time),
          technical_specs: qtnForm.tech_specs,
          total_quote_rate: Number(qtnForm.rate)
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Quotation ${data.data.id} submitted for review approval.`, "success");
        loadTransactions();
      } else {
        addToast(data.message || "Failed to submit quotation.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Quotation creation.", "success");
      const mockId = `QTN-26000${quotations.length + 1}`;
      const enq = enquiries.find(e => e.id === qtnForm.enquiry_id) || { customer_id: 'CUST001', customer_name: 'Tata Motors' };
      const newQtn = {
        id: mockId,
        enquiry_id: qtnForm.enquiry_id,
        customer_id: enq.customer_id,
        customer_name: enq.customer_name,
        costing_details: qtnForm.costing,
        lead_time_weeks: Number(qtnForm.lead_time),
        technical_specs: qtnForm.tech_specs,
        total_quote_rate: Number(qtnForm.rate),
        date: new Date().toISOString().split('T')[0],
        status: 'Pending Approval',
        approved_by: null
      };
      setQuotations(prev => [...prev, newQtn]);
    }
  };

  // Sales Head Approval Workflow simulation
  const approveQuotation = async (qtnId) => {
    try {
      const res = await fetch(`/api/sales/quotation/${qtnId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approver_name: "Sales Head Vikram" })
      });
      if (res.ok) {
        addToast(`Quotation ${qtnId} APPROVED by Sales Head.`, "success");
        loadTransactions();
      } else {
        const data = await res.json();
        addToast(data.message || "Approval failed.");
      }
    } catch (err) {
      addToast("Server offline. Mock approving quotation.", "success");
      setQuotations(prev => prev.map(q => q.id === qtnId ? { ...q, status: 'Approved', approved_by: 'Sales Head Vikram' } : q));
    }
  };

  // Step 3: Purchase Order Submit
  const handlePOSubmit = async (e) => {
    e.preventDefault();
    if (!poForm.quotation_id) {
      addToast("Interlock: PO must reference a valid Quotation.", "error");
      return;
    }

    // Client-side validation checks
    const targetQtn = quotations.find(q => q.id === poForm.quotation_id);
    if (targetQtn && targetQtn.status !== 'Approved') {
      addToast(`Interlock Blocked: Quotation ${poForm.quotation_id} must be APPROVED by Sales Head first.`, "error");
      return;
    }

    try {
      // Find the product related to this quotation enquiry
      // For simplicity, fetch from enquiries
      const enq = enquiries.find(eq => eq.id === targetQtn.enquiry_id);
      const prodId = enq ? enq.items[0].product_id : (products[0]?.id || 'PROD001');

      const res = await fetch('/api/sales/po', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          po_number: poForm.po_number,
          quotation_id: poForm.quotation_id,
          date: poForm.date,
          order_items: [{ product_id: prodId, quantity: Number(poForm.qty), rate: Number(poForm.rate) }]
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Purchase Order ${poForm.po_number} recorded.`, "success");
        loadTransactions();
        setActiveStep('workorder');
      } else {
        addToast(data.message || "Failed to record PO.");
      }
    } catch (err) {
      addToast("Server offline. Mock recording Purchase Order.", "success");
      const mockId = `PO-26000${pos.length + 1}`;
      const qtn = quotations.find(q => q.id === poForm.quotation_id) || { customer_id: 'CUST001', customer_name: 'Tata Motors' };
      const newPO = {
        id: mockId,
        po_number: poForm.po_number,
        quotation_id: poForm.quotation_id,
        customer_id: qtn.customer_id,
        customer_name: qtn.customer_name,
        date: poForm.date,
        order_items: [{ product_id: 'PROD001', quantity: Number(poForm.qty), rate: Number(poForm.rate) }],
        status: 'Active'
      };
      setPOs(prev => [...prev, newPO]);
      setActiveStep('workorder');
    }
  };

  // Step 4: Create Work Order (Internal production trigger)
  const handleWOSubmit = async (e) => {
    e.preventDefault();
    if (!woForm.po_id) {
      addToast("Interlock: Work Order only created against active PO reference.", "error");
      return;
    }

    try {
      const res = await fetch('/api/sales/wo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          po_id: woForm.po_id,
          schedule_delivery_date: woForm.delivery_date
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        addToast(`Work Orders successfully generated from PO items.`, "success");
        loadTransactions();
      } else {
        addToast(data.message || "Failed to generate Work Orders.");
      }
    } catch (err) {
      addToast("Server offline. Mock generating Work Orders.", "success");
      const poObj = pos.find(p => p.id === woForm.po_id) || { po_number: 'PO-MOCK', order_items: [] };
      const mockWOs = (poObj.order_items.length ? poObj.order_items : [{ product_id: 'PROD001', quantity: 100 }]).map((item, idx) => {
        const prod = products.find(p => p.id === item.product_id) || { name: 'Flywheel Housing', code: 'FW-HOUSING', grade_id: 'GR_FG260' };
        return {
          id: `WO-26000${wos.length + idx + 1}`,
          po_id: woForm.po_id,
          po_number: poObj.po_number,
          product_id: item.product_id,
          product_name: prod.name,
          product_code: prod.code,
          grade_id: prod.grade_id,
          grade_name: "FG260 (Grey Iron)",
          quantity: item.quantity,
          net_weight_kg: 32,
          gross_weight_kg: 38,
          schedule_delivery_date: woForm.delivery_date,
          status: 'Pending Planning',
          planned_qty: 0,
          produced_qty: 0,
          dispatched_qty: 0
        };
      });
      setWOs(prev => [...prev, ...mockWOs]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold text-white">Sales & Order Processing</h1>
          <p className="text-slate-400 text-sm mt-1">Interlocked process: Enquiry → Approved Quotation → PO → Work Order</p>
        </div>
        
        {/* Visual Progress Steps Indicators */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-lg">
          {['enquiry', 'quotation', 'po', 'workorder'].map((step, idx) => (
            <React.Fragment key={step}>
              <button 
                onClick={() => setActiveStep(step)}
                className={`px-3 py-1.5 text-xs font-bold rounded uppercase tracking-wider transition-all ${activeStep === step ? 'bg-orange-500 text-white' : 'text-slate-500 hover:text-slate-300'}`}
              >
                Step {idx+1}: {step}
              </button>
              {idx < 3 && <ChevronRight className="w-3.5 h-3.5 text-slate-700" />}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT/MID COLUMN: Form Panel */}
        <div className="glass-card col-span-1 lg:col-span-2">
          
          {/* STEP 1: ENQUIRY */}
          {activeStep === 'enquiry' && (
            <form onSubmit={handleEnquirySubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-orange-500" /> Step 1: Log Customer Enquiry
              </h3>
              
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Customer Name</label>
                  <select className="form-control" required value={enqForm.customer_id} onChange={e=>setEnqForm({...enqForm, customer_id: e.target.value})}>
                    <option value="">-- Select Customer Master --</option>
                    {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Product to Enquire</label>
                  <select className="form-control" required value={enqForm.product_id} onChange={e=>setEnqForm({...enqForm, product_id: e.target.value})}>
                    <option value="">-- Choose Product --</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.code})</option>)}
                  </select>
                </div>
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Required Quantity (nos)</label>
                  <input type="number" className="form-control" required value={enqForm.quantity} onChange={e=>setEnqForm({...enqForm, quantity: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Target Delivery Date</label>
                  <input type="date" className="form-control" required value={enqForm.target_date} onChange={e=>setEnqForm({...enqForm, target_date: e.target.value})} />
                </div>
                <div className="form-group flex items-center pt-8">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="form-checkbox bg-slate-900 border-slate-800" checked={enqForm.is_new_dev} onChange={e=>setEnqForm({...enqForm, is_new_dev: e.target.checked})} />
                    <span className="text-xs font-semibold uppercase text-slate-300">New Product Development Tag</span>
                  </label>
                </div>
              </div>

              <button type="submit" className="btn btn-primary">Submit Customer Enquiry</button>
            </form>
          )}

          {/* STEP 2: QUOTATION */}
          {activeStep === 'quotation' && (
            <form onSubmit={handleQuotationSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-orange-500" /> Step 2: Technical Costing & Quotation
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Reference Enquiry ID</label>
                  <select className="form-control" required value={qtnForm.enquiry_id} onChange={e=>setQtnForm({...qtnForm, enquiry_id: e.target.value})}>
                    <option value="">-- Choose Pending Enquiry --</option>
                    {enquiries.filter(enq => enq.status === 'Pending Quotation').map(enq => (
                      <option key={enq.id} value={enq.id}>{enq.id} - {enq.customer_name}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Quoted Rate per Casting ($/kg or flat)</label>
                  <input type="number" className="form-control" required value={qtnForm.rate} onChange={e=>setQtnForm({...qtnForm, rate: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Manufacturing Lead Time (Weeks)</label>
                  <input type="number" className="form-control" required value={qtnForm.lead_time} onChange={e=>setQtnForm({...qtnForm, lead_time: e.target.value})} />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Detailed Costing Estimation Details</label>
                <textarea className="form-control h-20" required value={qtnForm.costing} onChange={e=>setQtnForm({...qtnForm, costing: e.target.value})} />
              </div>

              <div className="form-group">
                <label className="form-label">Technical Specs / Special Testing Demands</label>
                <input type="text" className="form-control" value={qtnForm.tech_specs} onChange={e=>setQtnForm({...qtnForm, tech_specs: e.target.value})} />
              </div>

              <button type="submit" className="btn btn-primary">Generate & Send Quotation</button>
            </form>
          )}

          {/* STEP 3: PURCHASE ORDER */}
          {activeStep === 'po' && (
            <form onSubmit={handlePOSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-orange-500" /> Step 3: Log Received Purchase Order (PO)
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Reference Approved Quotation</label>
                  <select className="form-control" required value={poForm.quotation_id} onChange={e=>setPoForm({...poForm, quotation_id: e.target.value})}>
                    <option value="">-- Choose Quotation --</option>
                    {quotations.map(qtn => (
                      <option key={qtn.id} value={qtn.id}>
                        {qtn.id} ({qtn.customer_name}) - status: {qtn.status}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Purchase Order (PO) No.</label>
                  <input type="text" className="form-control" placeholder="PO/TATA/998" required value={poForm.po_number} onChange={e=>setPoForm({...poForm, po_number: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">PO Date</label>
                  <input type="date" className="form-control" required value={poForm.date} onChange={e=>setPoForm({...poForm, date: e.target.value})} />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                <h4 className="font-bold text-xs text-orange-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" /> Rate & Quantity Interlock Check
                </h4>
                <p className="text-[11px] text-slate-500 mb-3">Rate and quantity details must reflect negotiation quotes logged in Quotations.</p>
                <div className="form-grid">
                  <div className="form-group">
                    <label className="form-label">Order Quantity</label>
                    <input type="number" className="form-control" value={poForm.qty} onChange={e=>setPoForm({...poForm, qty: e.target.value})} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Order Rate ($)</label>
                    <input type="number" className="form-control" value={poForm.rate} onChange={e=>setPoForm({...poForm, rate: e.target.value})} />
                  </div>
                </div>
              </div>

              <button type="submit" className="btn btn-primary">Confirm & Register PO</button>
            </form>
          )}

          {/* STEP 4: WORK ORDER */}
          {activeStep === 'workorder' && (
            <form onSubmit={handleWOSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <Play className="w-5 h-5 text-orange-500" /> Step 4: Issue Internal Work Order (Production Job)
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Select Active Purchase Order</label>
                  <select className="form-control" required value={woForm.po_id} onChange={e=>setWoForm({...woForm, po_id: e.target.value})}>
                    <option value="">-- Select Active PO --</option>
                    {pos.map(po => (
                      <option key={po.id} value={po.id}>{po.po_number} ({po.customer_name})</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Internal Schedule Production End Date</label>
                  <input type="date" className="form-control" required value={woForm.delivery_date} onChange={e=>setWoForm({...woForm, delivery_date: e.target.value})} />
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800">
                <p className="text-[11px] text-slate-500 leading-normal">
                  <strong>Interlocking Automation:</strong> Issuing the Work Order autofetches product definitions, grade specifications (chemical specs), net casting weight and routes them directly to production line logs.
                </p>
              </div>

              <button type="submit" className="btn btn-primary">Generate Work Orders</button>
            </form>
          )}

        </div>

        {/* RIGHT COLUMN: Database logs / Active lists */}
        <div className="glass-card col-span-1 border-slate-800 bg-slate-950/20">
          <h3 className="font-bold text-white text-base border-b border-slate-800 pb-2 mb-3">
            Active {activeStep === 'enquiry' ? 'Enquiries' : activeStep === 'quotation' ? 'Quotations' : activeStep === 'po' ? 'PO Registries' : 'Work Orders (WO)'}
          </h3>

          <div className="space-y-3 overflow-y-auto max-h-[480px] pr-1">
            
            {/* Enquiry list */}
            {activeStep === 'enquiry' && enquiries.map(enq => (
              <div key={enq.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-mono text-xs text-orange-500 font-bold">{enq.id}</span>
                  <span className="badge badge-info">{enq.status}</span>
                </div>
                <h4 className="font-bold text-sm text-slate-200 mt-1">{enq.customer_name}</h4>
                <p className="text-[11px] text-slate-500 mt-1">Due: {enq.target_date}</p>
              </div>
            ))}

            {/* Quotations List with Approvals */}
            {activeStep === 'quotation' && quotations.map(q => (
              <div key={q.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-mono text-xs text-orange-500 font-bold">{q.id}</span>
                  <span className={`badge ${q.status === 'Approved' ? 'badge-success' : 'badge-warning'}`}>{q.status}</span>
                </div>
                <h4 className="font-bold text-sm text-slate-200 mt-1">{q.customer_name}</h4>
                <div className="text-xs text-slate-400 mt-1">Rate Quoted: ${q.total_quote_rate}</div>
                {q.status === 'Pending Approval' ? (
                  <button 
                    onClick={() => approveQuotation(q.id)} 
                    className="w-full mt-2 py-1 text-xs btn-success text-center rounded font-bold"
                  >
                    Sales Head: Approve Costing
                  </button>
                ) : (
                  <p className="text-[10px] text-emerald-400 font-bold mt-2">Approved by: {q.approved_by || "Sales Head"}</p>
                )}
              </div>
            ))}

            {/* Purchase Orders List */}
            {activeStep === 'po' && pos.map(p => (
              <div key={p.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-mono text-xs text-slate-500 font-bold">{p.po_number}</span>
                  <span className="badge badge-success">{p.status}</span>
                </div>
                <h4 className="font-bold text-sm text-slate-200 mt-1">{p.customer_name}</h4>
                <p className="text-[11px] text-slate-500 mt-1">PO Date: {p.date}</p>
              </div>
            ))}

            {/* Work Orders List */}
            {activeStep === 'workorder' && wos.map(w => (
              <div key={w.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-mono text-xs text-orange-500 font-bold">{w.id}</span>
                  <span className="badge badge-info">{w.status}</span>
                </div>
                <h4 className="font-bold text-xs text-white mt-1">{w.product_name}</h4>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">{w.grade_name}</div>
                <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-500">
                  <div>Qty: <span className="text-white font-bold">{w.quantity}</span></div>
                  <div>Planned: <span className="text-white font-bold">{w.planned_qty}</span></div>
                </div>
              </div>
            ))}

            {((activeStep === 'enquiry' && enquiries.length === 0) ||
              (activeStep === 'quotation' && quotations.length === 0) ||
              (activeStep === 'po' && pos.length === 0) ||
              (activeStep === 'workorder' && wos.length === 0)) && (
              <p className="text-xs text-slate-600 text-center py-10">No records found. Complete previous step first.</p>
            )}

          </div>
        </div>

      </div>
    </div>
  );
}

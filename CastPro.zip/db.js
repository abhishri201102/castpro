import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(process.cwd(), 'foundry_db.json');

const INITIAL_DATA = {
  users: [
    { id: "U001", username: "admin", password: "123", role: "Admin", full_name: "System Administrator" },
    { id: "U002", username: "sales", password: "123", role: "Sales", full_name: "Vikram Kumar (Sales Head)" },
    { id: "U003", username: "prod", password: "123", role: "Production", full_name: "Rajesh Sharma (Prod Manager)" },
    { id: "U004", username: "quality", password: "123", role: "Quality", full_name: "Dr. Amit Patel (QC Lead)" },
    { id: "U005", username: "dispatch", password: "123", role: "Dispatch", full_name: "Sanjay Verma (Dispatch In-charge)" }
  ],
  customers: [
    { id: "CUST001", name: "Tata Motors Ltd", contact: "9876543210", address: "Pune Plant, Maharashtra", email: "procurement@tatamotors.com" },
    { id: "CUST002", name: "Mahindra & Mahindra", contact: "9876543211", address: "Chakan, Maharashtra", email: "info@mahindra.com" },
    { id: "CUST003", name: "KSB Pumps Ltd", contact: "9876543212", address: "Coimbatore, Tamil Nadu", email: "purchase@ksbpumps.com" }
  ],
  suppliers: [
    { id: "SUPP001", name: "Steel Authority of India (SAIL)", contact: "9112233445", address: "Bhilai Steel Plant", email: "sales@sail.in" },
    { id: "SUPP002", name: "Alloy Miners Corp", contact: "9223344556", address: "Kolkata, WB", email: "alloys@miners.com" }
  ],
  units: [
    { id: "U_KG", code: "kg", name: "Kilogram" },
    { id: "U_NOS", code: "nos", name: "Numbers (Pieces)" },
    { id: "U_TON", code: "ton", name: "Metric Ton" }
  ],
  grades: [
    { 
      id: "GR_FG260", 
      name: "FG260 (Grey Iron)", 
      chemical: {
        C: { min: 3.10, max: 3.40 },
        Si: { min: 1.80, max: 2.10 },
        Mn: { min: 0.60, max: 0.90 },
        S: { min: 0.00, max: 0.12 },
        P: { min: 0.00, max: 0.15 }
      },
      mechanical: {
        tensile_min: 260,
        hardness_min: 180,
        hardness_max: 230,
        elongation_min: 0
      }
    },
    { 
      id: "GR_SG400", 
      name: "SG400/15 (Ductile Iron)", 
      chemical: {
        C: { min: 3.50, max: 3.85 },
        Si: { min: 2.20, max: 2.80 },
        Mn: { min: 0.00, max: 0.40 },
        Mg: { min: 0.03, max: 0.06 },
        S: { min: 0.00, max: 0.02 },
        P: { min: 0.00, max: 0.05 }
      },
      mechanical: {
        tensile_min: 400,
        hardness_min: 130,
        hardness_max: 180,
        elongation_min: 15
      }
    },
    { 
      id: "GR_WCB", 
      name: "WCB Cast Carbon Steel", 
      chemical: {
        C: { min: 0.00, max: 0.30 },
        Si: { min: 0.00, max: 0.60 },
        Mn: { min: 0.00, max: 1.00 },
        S: { min: 0.00, max: 0.045 },
        P: { min: 0.00, max: 0.035 }
      },
      mechanical: {
        tensile_min: 485,
        hardness_min: 140,
        hardness_max: 200,
        elongation_min: 22
      }
    }
  ],
  products: [
    { id: "PROD001", code: "FW-HOUSING-TATA", name: "Flywheel Housing", drawing_no: "TATA-FW-102-R3", grade_id: "GR_FG260", net_weight: 32.0, gross_weight: 38.5, customer_id: "CUST001", unit_id: "U_NOS" },
    { id: "PROD002", code: "CRANKSHAFT-MM", name: "Crankshaft 4-Cyl", drawing_no: "MM-CS-451-REV2", grade_id: "GR_SG400", net_weight: 18.2, gross_weight: 22.0, customer_id: "CUST002", unit_id: "U_NOS" },
    { id: "PROD003", code: "CASING-KSB-899", name: "Pump Casing 899", drawing_no: "KSB-PC-899-A", grade_id: "GR_WCB", net_weight: 45.0, gross_weight: 55.0, customer_id: "CUST003", unit_id: "U_NOS" }
  ],
  inventory: [
    { id: "INV001", name: "Pig Iron", stock: 12500, min_stock: 5000, unit: "kg" },
    { id: "INV002", name: "Steel Scrap", stock: 18000, min_stock: 8000, unit: "kg" },
    { id: "INV003", name: "Ferro-Silicon", stock: 1500, min_stock: 500, unit: "kg" },
    { id: "INV004", name: "Ferro-Manganese", stock: 1200, min_stock: 400, unit: "kg" },
    { id: "INV005", name: "Magnesium Alloy", stock: 650, min_stock: 200, unit: "kg" }
  ],
  enquiries: [],
  quotations: [],
  purchase_orders: [],
  work_orders: [],
  production_plans: [],
  melting_heats: [],
  chemical_tests: [],
  melting_log_materials: [],
  castings: [],
  rejection_logs: [],
  dispatch_memos: []
};

// Write locks to simulate transaction safety
let isWriting = false;

function loadDatabase() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(INITIAL_DATA, null, 2), 'utf8');
      return INITIAL_DATA;
    }
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error("Error loading database, returning initial schema:", err);
    return INITIAL_DATA;
  }
}

function saveDatabase(data) {
  if (isWriting) {
    // Retry writing after a tiny delay
    setTimeout(() => saveDatabase(data), 5);
    return;
  }
  isWriting = true;
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error("Error saving database:", err);
  } finally {
    isWriting = false;
  }
}

export const db = {
  getAll: (table) => {
    const data = loadDatabase();
    return data[table] || [];
  },

  getById: (table, id) => {
    const data = loadDatabase();
    return (data[table] || []).find(item => item.id === id);
  },

  insert: (table, item) => {
    const data = loadDatabase();
    if (!data[table]) data[table] = [];
    
    // Generate simple readable IDs based on tables
    if (!item.id) {
      const prefix = {
        enquiries: "ENQ",
        quotations: "QTN",
        purchase_orders: "PO",
        work_orders: "WO",
        production_plans: "PLN",
        melting_heats: "HEAT",
        chemical_tests: "CHEM",
        melting_log_materials: "MLM",
        castings: "CAST",
        rejection_logs: "REJ",
        dispatch_memos: "MEMO"
      }[table] || "ID";
      
      const count = data[table].length + 1;
      item.id = `${prefix}-${new Date().getFullYear().toString().substr(-2)}${String(count).padStart(4, '0')}`;
    }
    
    data[table].push(item);
    saveDatabase(data);
    return item;
  },

  update: (table, id, updatedFields) => {
    const data = loadDatabase();
    if (!data[table]) return null;
    
    const index = data[table].findIndex(item => item.id === id);
    if (index === -1) return null;
    
    data[table][index] = { ...data[table][index], ...updatedFields };
    saveDatabase(data);
    return data[table][index];
  },

  delete: (table, id) => {
    const data = loadDatabase();
    if (!data[table]) return false;
    
    const initialLen = data[table].length;
    data[table] = data[table].filter(item => item.id !== id);
    if (data[table].length < initialLen) {
      saveDatabase(data);
      return true;
    }
    return false;
  },

  // Helper for direct modifications
  saveAll: (table, list) => {
    const data = loadDatabase();
    data[table] = list;
    saveDatabase(data);
  }
};

import React, { useState, useEffect } from 'react';
import { Microscope, ShieldAlert, Award, FileSpreadsheet, Eye, Paintbrush, Hammer } from 'lucide-react';

export default function Quality({ addToast }) {
  const [activeQCSubTab, setActiveQCSubTab] = useState('knockout');

  // Database lists
  const [castings, setCastings] = useState([]);
  const [heats, setHeats] = useState([]);
  const [grades, setGrades] = useState([]);
  const [rejectionsList, setRejectionsList] = useState([]);
  
  // Selection states
  const [selectedCastings, setSelectedCastings] = useState([]);
  
  // Forms
  const [rejectReason, setRejectReason] = useState('Sand Inclusion');
  const [rootCause, setRootCause] = useState('Sand Moisture Control');
  const [mechForm, setMechForm] = useState({ heat_id: '', tensile: 275, hardness: 195, elongation: 2 });

  useEffect(() => {
    fetchQCData();
  }, [activeQCSubTab]);

  const fetchQCData = async () => {
    try {
      const resCast = await fetch('/api/masters/castings');
      const resHeat = await fetch('/api/masters/melting_heats');
      const resGrades = await fetch('/api/masters/grades');
      const resRej = await fetch('/api/analytics/rejections');

      if (resCast.ok) setCastings(await resCast.json());
      if (resHeat.ok) setHeats(await resHeat.json());
      if (resGrades.ok) setGrades(await resGrades.json());
      if (resRej.ok) setRejectionsList(await resRej.json());
    } catch (err) {
      console.warn("Offline fallback for QC data loading");
      // Populate realistic mock castings offline for testing
      setCastings([
        { id: 'CAST-26-00001', heat_id: 'HEAT-26001', product_name: 'Flywheel Housing', stage: 'Knockout Pending', knockout_status: 'Pending', quality_status: 'Pending', painting_status: 'Pending' },
        { id: 'CAST-26-00002', heat_id: 'HEAT-26001', product_name: 'Flywheel Housing', stage: 'Knockout Pending', knockout_status: 'Pending', quality_status: 'Pending', painting_status: 'Pending' },
        { id: 'CAST-26-00003', heat_id: 'HEAT-26001', product_name: 'Flywheel Housing', stage: 'Knockout Inspected', knockout_status: 'Accepted', quality_status: 'Pending', painting_status: 'Pending' },
        { id: 'CAST-26-00004', heat_id: 'HEAT-26002', product_name: 'Crankshaft 4-Cyl', stage: 'Fettled', knockout_status: 'Accepted', quality_status: 'Pending', painting_status: 'Pending' },
        { id: 'CAST-26-00005', heat_id: 'HEAT-26002', product_name: 'Crankshaft 4-Cyl', stage: 'Fettling Inspected', knockout_status: 'Accepted', quality_status: 'Accepted', painting_status: 'Pending' }
      ]);
      setHeats([
        { id: 'HEAT-26001', grade_name: 'FG260 (Grey Iron)', grade_id: 'GR_FG260', heat_date: '2026-05-25', chemical_status: 'Passed', mechanical_status: 'Pending Testing' },
        { id: 'HEAT-26002', grade_name: 'SG400/15 (Ductile Iron)', grade_id: 'GR_SG400', heat_date: '2026-05-25', chemical_status: 'Passed', mechanical_status: 'Pending Testing' }
      ]);
    }
    setSelectedCastings([]);
  };

  const handleSelectionToggle = (id) => {
    setSelectedCastings(prev => 
      prev.includes(id) ? prev.filter(cId => cId !== id) : [...prev, id]
    );
  };

  const handleSelectAll = (filteredItems) => {
    if (selectedCastings.length === filteredItems.length) {
      setSelectedCastings([]);
    } else {
      setSelectedCastings(filteredItems.map(item => item.id));
    }
  };

  // Inspect Post Knockout
  const submitKnockoutInspection = async (status) => {
    if (selectedCastings.length === 0) {
      addToast("Please select at least one casting to inspect.", "error");
      return;
    }

    try {
      const res = await fetch('/api/quality/knockout/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          casting_ids: selectedCastings,
          status,
          rejection_reason: status === 'Rejected' ? rejectReason : null,
          root_cause_tag: status === 'Rejected' ? rootCause : null
        })
      });
      if (res.ok) {
        addToast(`Knockout inspection completed for selected castings.`, "success");
        fetchQCData();
      } else {
        const data = await res.json();
        addToast(data.message || "Failed to submit inspection.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Knockout Inspection.", "success");
      setCastings(prev => prev.map(c => 
        selectedCastings.includes(c.id) ? {
          ...c,
          stage: status === 'Accepted' ? 'Knockout Inspected' : 'Knockout Rejected',
          knockout_status: status
        } : c
      ));
      setSelectedCastings([]);
    }
  };

  // Mechanical specs labs testing submit
  const handleMechanicalTestSubmit = async (e) => {
    e.preventDefault();
    if (!mechForm.heat_id) {
      addToast("Please select reference Heat No.", "error");
      return;
    }

    try {
      const res = await fetch('/api/quality/mechanical/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          heat_id: mechForm.heat_id,
          tensile_strength: Number(mechForm.tensile),
          hardness_bhn: Number(mechForm.hardness),
          elongation_percent: Number(mechForm.elongation)
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.passed) {
          addToast("Mechanical verification PASSED! Certificate approved.", "success");
          fetchQCData();
        } else {
          addToast("INTERLOCK WARNING: Mechanical values failed Grade specs! Dispatch is BLOCKED.", "error");
          fetchQCData();
        }
      } else {
        addToast(data.message || "Test registration failed.");
      }
    } catch (err) {
      addToast("Server offline. Mocking mechanical test log.", "success");
      setHeats(prev => prev.map(h => h.id === mechForm.heat_id ? { ...h, mechanical_status: 'Passed' } : h));
    }
  };

  // Move to Fettling Shop
  const sendToFettling = async () => {
    if (selectedCastings.length === 0) {
      addToast("Select castings to move.", "error");
      return;
    }

    try {
      const res = await fetch('/api/quality/fettling/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ casting_ids: selectedCastings })
      });
      if (res.ok) {
        addToast("Castings transferred to Fettling grinding.", "success");
        fetchQCData();
      } else {
        const data = await res.json();
        addToast(data.message || "Transfer failed.");
      }
    } catch (err) {
      addToast("Server offline. Mock transferring to Fettling.", "success");
      setCastings(prev => prev.map(c => selectedCastings.includes(c.id) ? { ...c, stage: 'Fettled', fettling_status: 'Processed' } : c));
      setSelectedCastings([]);
    }
  };

  // Inspect Fettled Castings
  const submitFettlingInspection = async (status) => {
    if (selectedCastings.length === 0) {
      addToast("Select castings to inspect.", "error");
      return;
    }

    try {
      const res = await fetch('/api/quality/fettling/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          casting_ids: selectedCastings,
          status,
          rejection_reason: status === 'Rejected' ? rejectReason : null,
          root_cause_tag: status === 'Rejected' ? rootCause : null
        })
      });
      if (res.ok) {
        addToast(`Fettling inspection updated.`, "success");
        fetchQCData();
      } else {
        const data = await res.json();
        addToast(data.message || "Failed to submit inspection.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Fettling inspection.", "success");
      setCastings(prev => prev.map(c => 
        selectedCastings.includes(c.id) ? {
          ...c,
          stage: status === 'Accepted' ? 'Fettling Inspected' : status === 'Rework' ? 'Knockout Inspected' : 'Fettling Rejected',
          quality_status: status === 'Accepted' ? 'Accepted' : 'Pending'
        } : c
      ));
      setSelectedCastings([]);
    }
  };

  // Painting approval (Final step before clearance)
  const approvePainting = async () => {
    if (selectedCastings.length === 0) {
      addToast("Select castings to finish.", "error");
      return;
    }

    try {
      const res = await fetch('/api/quality/painting/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ casting_ids: selectedCastings })
      });
      if (res.ok) {
        addToast("Painting completed. Castings cleared to Dispatch pool.", "success");
        fetchQCData();
      } else {
        const data = await res.json();
        addToast(data.message || "Failed to approve painting.");
      }
    } catch (err) {
      addToast("Server offline. Mocking Painting completion.", "success");
      setCastings(prev => prev.map(c => selectedCastings.includes(c.id) ? { ...c, stage: 'Painted', painting_status: 'Approved' } : c));
      setSelectedCastings([]);
    }
  };

  // Filters based on tab
  const getFilteredCastings = () => {
    switch (activeQCSubTab) {
      case 'knockout': 
        return castings.filter(c => c.stage === 'Knockout Pending');
      case 'fettling': 
        return castings.filter(c => c.stage === 'Knockout Inspected');
      case 'fettlingInspect': 
        return castings.filter(c => c.stage === 'Fettled');
      case 'painting': 
        return castings.filter(c => c.stage === 'Fettling Inspected' && c.quality_status === 'Accepted');
      default: 
        return [];
    }
  };

  const filteredItems = getFilteredCastings();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold text-white">Quality Inspection Labs</h1>
          <p className="text-slate-400 text-sm mt-1">Validation gates: Knockout → Laboratory Mechanical tests → Fettling → Painting</p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-lg">
          {['knockout', 'mechanical', 'fettling', 'fettlingInspect', 'painting'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveQCSubTab(tab)}
              className={`px-3 py-1.5 text-xs font-bold rounded uppercase tracking-wider transition-all ${activeQCSubTab === tab ? 'bg-orange-500 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              {tab === 'fettlingInspect' ? 'Fettling QC' : tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: Main QC Action Table/Form */}
        <div className="glass-card col-span-1 lg:col-span-2">
          
          {/* TAB: LAB MECHANICAL TESTING */}
          {activeQCSubTab === 'mechanical' && (
            <form onSubmit={handleMechanicalTestSubmit} className="space-y-4">
              <h3 className="font-bold text-white text-lg border-b border-slate-800 pb-3 mb-4 flex items-center gap-2">
                <Microscope className="w-5 h-5 text-orange-500" /> Laboratory Mechanical Properties Log
              </h3>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Choose Furnace Heat ID</label>
                  <select className="form-control" required value={mechForm.heat_id} onChange={e=>setMechForm({...mechForm, heat_id: e.target.value})}>
                    <option value="">-- Choose Heat --</option>
                    {heats.filter(h=>h.mechanical_status === 'Pending Testing').map(h => (
                      <option key={h.id} value={h.id}>{h.id} ({h.grade_name})</option>
                    ))}
                  </select>
                </div>
                
                <div className="form-group">
                  <label className="form-label">Tensile Strength (MPa)</label>
                  <input type="number" className="form-control" required value={mechForm.tensile} onChange={e=>setMechForm({...mechForm, tensile: e.target.value})} />
                </div>
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Brinell Hardness (BHN)</label>
                  <input type="number" className="form-control" required value={mechForm.hardness} onChange={e=>setMechForm({...mechForm, hardness: e.target.value})} />
                </div>
                <div className="form-group">
                  <label className="form-label">Elongation (%)</label>
                  <input type="number" step="0.1" className="form-control" required value={mechForm.elongation} onChange={e=>setMechForm({...mechForm, elongation: e.target.value})} />
                </div>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <p className="text-[11px] text-slate-500 leading-normal">
                  <strong>Lab Safety Checklist:</strong> Submitting these measurements validates the tensile strength and hardness levels against the grade specification bounds. Failure to reach minima will automatically flag castings from this Heat No, and block their final dispatch.
                </p>
              </div>

              <button type="submit" className="btn btn-primary" disabled={!mechForm.heat_id}>Record Lab Results</button>
            </form>
          )}

          {/* OTHER TABS: Castings List with Checkboxes */}
          {activeQCSubTab !== 'mechanical' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-bold text-white text-lg flex items-center gap-2">
                  {activeQCSubTab === 'knockout' && <><Hammer className="w-5 h-5 text-orange-500" /> Knockout Inspection</>}
                  {activeQCSubTab === 'fettling' && <><Award className="w-5 h-5 text-orange-500" /> Fettling Shop Transfer</>}
                  {activeQCSubTab === 'fettlingInspect' && <><ShieldAlert className="w-5 h-5 text-orange-500" /> Fettling Quality Check</>}
                  {activeQCSubTab === 'painting' && <><Paintbrush className="w-5 h-5 text-orange-500" /> Painting Finishing Approval</>}
                </h3>
                
                {filteredItems.length > 0 && (
                  <button 
                    onClick={() => handleSelectAll(filteredItems)} 
                    className="text-xs text-orange-400 font-bold bg-slate-900 border border-slate-800 px-3 py-1 rounded"
                  >
                    {selectedCastings.length === filteredItems.length ? "Deselect All" : "Select All"}
                  </button>
                )}
              </div>

              {/* Table of castings */}
              <div className="table-container max-h-[360px] overflow-y-auto">
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th style={{ width: '40px' }}>Select</th>
                      <th>Casting Serial</th>
                      <th>Heat ID</th>
                      <th>Product Model Name</th>
                      <th>Current Stage</th>
                      <th>Inspection Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredItems.map(item => (
                      <tr key={item.id} className={selectedCastings.includes(item.id) ? 'bg-slate-900/60' : ''}>
                        <td>
                          <input 
                            type="checkbox" 
                            className="bg-slate-950 border-slate-800 rounded cursor-pointer"
                            checked={selectedCastings.includes(item.id)} 
                            onChange={() => handleSelectionToggle(item.id)} 
                          />
                        </td>
                        <td className="font-mono text-xs font-bold text-white">{item.id}</td>
                        <td className="font-mono text-xs text-slate-400">{item.heat_id}</td>
                        <td>{item.product_name}</td>
                        <td>
                          <span className="badge badge-info">{item.stage}</span>
                        </td>
                        <td>
                          <span className={`badge ${item.knockout_status === 'Accepted' ? 'badge-success' : 'badge-warning'}`}>
                            K.O: {item.knockout_status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredItems.length === 0 && (
                  <p className="text-xs text-slate-500 text-center py-10">No castings pending at this stage.</p>
                )}
              </div>

              {/* Rejection Cause logger details for inspectors */}
              {selectedCastings.length > 0 && (activeQCSubTab === 'knockout' || activeQCSubTab === 'fettlingInspect') && (
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 form-grid fade-in">
                  <div className="form-group col-span-2">
                    <label className="form-label text-red-400">If Rejecting, Enter Defect Category</label>
                    <select className="form-control" value={rejectReason} onChange={e=>setRejectReason(e.target.value)}>
                      <option value="Sand Inclusion">Sand Inclusion (Erosion/Wash)</option>
                      <option value="Gas Blowholes">Gas Blowholes (Moisture/Core gas)</option>
                      <option value="Core Shift">Core Shift / Dimensional mismatch</option>
                      <option value="Cold Shut">Cold Shut / Pouring temp too low</option>
                      <option value="Grinding Scar">Fettling scar / excessive grinding</option>
                    </select>
                  </div>
                  <div className="form-group col-span-2">
                    <label className="form-label text-slate-400">Suspected Root Cause Tag (For analytics)</label>
                    <input type="text" className="form-control" placeholder="e.g. Sand moisture, worker fatigue" value={rootCause} onChange={e=>setRootCause(e.target.value)} />
                  </div>
                </div>
              )}

              {/* Dynamic Action Buttons */}
              {selectedCastings.length > 0 && (
                <div className="flex gap-3 pt-2">
                  {activeQCSubTab === 'knockout' && (
                    <>
                      <button onClick={() => submitKnockoutInspection('Accepted')} className="btn btn-success">Approve Knockout ({selectedCastings.length})</button>
                      <button onClick={() => submitKnockoutInspection('Rejected')} className="btn btn-danger">Reject Castings ({selectedCastings.length})</button>
                    </>
                  )}
                  {activeQCSubTab === 'fettling' && (
                    <button onClick={sendToFettling} className="btn btn-primary">Transfer to Fettling Shop ({selectedCastings.length})</button>
                  )}
                  {activeQCSubTab === 'fettlingInspect' && (
                    <>
                      <button onClick={() => submitFettlingInspection('Accepted')} className="btn btn-success">Pass Fettling Inspection ({selectedCastings.length})</button>
                      <button onClick={() => submitFettlingInspection('Rework')} className="btn btn-secondary">Send for Rework ({selectedCastings.length})</button>
                      <button onClick={() => submitFettlingInspection('Rejected')} className="btn btn-danger">Reject Castings ({selectedCastings.length})</button>
                    </>
                  )}
                  {activeQCSubTab === 'painting' && (
                    <button onClick={approvePainting} className="btn btn-success flex items-center gap-2">
                      <Paintbrush className="w-4 h-4" /> Finish & Clear for Dispatch ({selectedCastings.length})
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Rejections Analysis logs */}
        <div className="glass-card col-span-1 border-slate-800 bg-slate-950/20">
          <h3 className="font-bold text-white text-base border-b border-slate-800 pb-2 mb-3">
            QC Laboratory Warnings & Rejections Log
          </h3>

          <div className="space-y-3 overflow-y-auto max-h-[480px]">
            {rejectionsList.map(rej => (
              <div key={rej.id} className="p-3 bg-red-950/10 border border-red-500/20 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-mono text-xs text-red-400 font-bold">{rej.casting_id}</span>
                  <span className="badge badge-danger">{rej.stage}</span>
                </div>
                <h4 className="font-bold text-xs text-white mt-1">Reason: {rej.reason}</h4>
                <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-red-950/20 text-[10px] text-slate-500">
                  <div>Heat ID: <span className="text-white font-mono">{rej.heat_id}</span></div>
                  <div>Root Cause: <span className="text-orange-400 font-semibold">{rej.root_cause_tag}</span></div>
                </div>
              </div>
            ))}
            {rejectionsList.length === 0 && (
              <p className="text-slate-600 text-center py-10 text-xs">No active rejections logged.</p>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
